export default function Test(){
    return(
        <div className="container-fluid" style={{padding: "16px", minWidth: "1000px", width: "calc(100% - 190px * 2)", margin: "0 auto"}}>
        
        <div className="page-wrapper ">
            <div className="container recipe-detail-container ">
                <div className="rm ">
                    <div className="breadcrumb ">
                        <ul>
                            <li className=" "><a href="https://www.cooky.vn/cong-thuc ">Công Thức</a></li>
                            <li className=" "><a href="https://www.cooky.vn/cach-lam/mon-sinh-to-nuoc-ep-ngon-d115 ">Sinh tố
                                    - Nước Ep</a></li>
                            <li className="active "><span>Smoothie xoài chuối kiwi - smoothie healthy bowl</span></li>
                        </ul>
                    </div>
                    <div className="recipe-main-photo"><img className="recipe-cover-photo" src="https://image.cooky.vn/recipe/g6/50880/s640/cooky-recipe-637102372207865706.png"/>
                    </div>
                    <div className="recipe-detail-content">

                   
                        <h3 className="recipe-name">Smoothie xoài chuối kiwi - smoothie healthy bowl</h3> 
                     

                        
                        <div className="button-recipe"><span>346 Đã lưu</span><img className="icon-like"/></div> 
                        


                        
                        <div className="recipe-stats-info"><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="1"/><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="2"/><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="3"/><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="4"/><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="5"/>
                            <span>9</span>
                            <div className="total-likes">
                                <img src="https://www.cooky.vn/React/images/icons/heart.svg"/><span>346</span>
                            </div>
                        
                            <div> 
                                <img src="https://www.cooky.vn/React/images/icons/view.svg"/><span>11k</span>
                            </div>
                          
                        </div> 
                        
                        
                        
                        <div className="recipe-owner"><a href="https://www.cooky.vn/thanh-vien/wenkimtuyen">
                                <div className="recipe-owner-avatar"><img src="https://image.cooky.vn/usr/g10/96128/avt/s140/cooky-avatar-636959526416611860.jpg"/>
                                </div>
                                <div className="recipe-owner-name">
                                    <h4>BẾP THÁNG 12</h4><span>22 công thức, 1k người theo dõi</span>
                                </div>
                            </a>
                            <div className="make-recipe-button"><img src="https://www.cooky.vn/React/images/icons/i-made-it-desktop.svg"/><span>I
                                    made it</span></div>
                        </div>
                        

                      
                        <div className="recipe-desc-less">
                            <p>Smoothie Healthy Bowl là một món ăn sáng hỗ trợ giảm cân, chăm sóc sức đẹp phổ biến ở
                                các nước Châu Âu và dần đang được ưa chuộng tại Việt Nam. Đây mà món ăn có thể giúp
                                bạn thỏa sức sáng tạo với nhiều loại trái cây, các loại hạt khác nhau. Với vẻ ngoài
                                vô cùng đẹp mắt và hương vị tươi mát, cách làm đơn giản, combo Smoothie Xoài Chuối
                                Kiwi sẽ làm bạn thích thú.</p>
                        </div>
                     

                       
                        <div className="recipe-ingredient">
                            <h3>Thành phần</h3><span>Khẩu phần: 2 người</span>
                        </div>
                        

                        <div id="ingredients-list">
                            <div className="ingredient-item"><span className="ingredient-name">Chuối</span><span className="ingredient-quantity">400 Gr</span></div>
                            <div className="ingredient-item"><span className="ingredient-name">Xoài chín</span><span className="ingredient-quantity">300 Gr</span></div>
                            <div className="ingredient-item"><span className="ingredient-name">Kiwi</span><span className="ingredient-quantity">300 Gr</span></div>
                            <div className="ingredient-item"><span className="ingredient-name">Củ dền</span><span className="ingredient-quantity">50 Gr</span></div>
                            <div className="ingredient-item"><span className="ingredient-name">Cam</span><span className="ingredient-quantity">100 Gr</span></div>
                            <div className="ingredient-item"><span className="ingredient-name">Hạt chia</span><span className="ingredient-quantity">30 Gr</span></div>
                            <div className="ingredient-item"><span className="ingredient-name">Yến mạch </span><span className="ingredient-quantity">100 Gr</span></div>
                        </div>
                        

                        
                        <div className="recipe-ads-banner-container">
                            <div className="banner-wrapper">
                                <div className="banner animated-place-holder"></div>
                            </div>
                        </div>
                
                        <div className="recipe-steps-list">
                            <h3 className="how-to-make">Hướng dẫn thực hiện</h3>
                            <div className="cook-step-content">
                                <div className="cook-step-item">
                                    <div className="step-number">1.</div>
                                    <div className="step-content">
                                        <p>Loại bỏ vỏ chuối, vỏ kiwi, vỏ xoài chín. Sau đó, cắt trái cây thành từng
                                            khoanh mỏng. Cho vào ngăn đá tủ lạnh ít nhất 2 tiếng.</p>
                                        <ul className="step-photos">
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102378373968618.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102378372508476.png"/>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="cook-step-item">
                                    <div className="step-number">2.</div>
                                    <div className="step-content">
                                        <p>Củ dền gọt bỏ vỏ, cắt khối vuông. Yến mạch bạn có thể sử dụng loại nguyên
                                            chất hoặc rang đường nâu đều được.</p>
                                        <ul className="step-photos">
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102379797673115.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102379793382655.png"/>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="cook-step-item">
                                    <div className="step-number">3.</div>
                                    <div className="step-content">
                                        <p>Sau khi trái cây đông đá, cho tất cả vào máy xay bao gồm 350 gram chuối,
                                            200 gram xoài chín, 200 gram kiwi vào xay mịn. Smoothie sẽ có màu vàng
                                            nhạt. Để smoothie có màu hồng, bạn có thể cho thêm củ dền vào nhé!</p>
                                        <ul className="step-photos">
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="cook-step-item">
                                    <div className="step-number">4.</div>
                                    <div className="step-content">
                                        <p>Sau khi xay mịn, cho hỗn họp ra tô. Trang trí phần trái cây cắt lát còn
                                            lại, hạt chia và yến mạch tùy theo sở thích.</p>
                                        <ul className="step-photos">
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="cook-step-item">
                                    <div className="step-number">5.</div>
                                    <div className="step-content">
                                        <p>Hãy bảo quản món ăn này trong ngăn đông để chúng tươi lâu hơn nhé. Bây
                                            giờ thưởng thức thôi. Trái cây chua ngọt đậm đà tự nhiên không cần
                                            đường, hòa cùng trái cây tươi mát lạnh, thêm ít yến mạch và hạt chia bổ
                                            dưỡng mát lạnh. Hãy sáng tạo và duy trì thói quen ăn món smoothie này để
                                            có một vóc dáng đẹp và một sức khỏe tốt nhé! Chúc các bạn thành công!
                                        </p>
                                        <ul className="step-photos">
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                            <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102382565212973.png"/>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                      


                        <h3 className="how-to-make">Bình luận</h3>
                        <div className="recipe-comment-form"><img src="https://www.cooky.vn/React/images/icons/photo.svg"/><span>Đăng
                                bình luận</span>
                            <div>Đăng</div>
                        </div>
                        <div className="recipe-review">
                            <div className="recipe-review-item"><img className="review-owner-avatar" src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/user-default.png"/>
                                <div className="review-item-info"><span className="review-owner-name">phamhue454</span><span className="review-created-day">05/03/2020</span>
                                    <div className="review-desc">Phần topping mình có thể thêm hạt, nho khô, dừa sấy...
                                        Nhân tiện, gáo dừa thì ra chợ chỗ bán dừa nạo mà xin. Người ta cũng bỏ rác
                                        chứ ai mà bán.</div>
                                </div>
                            </div>
                            <div className="recipe-review-item"><img className="review-owner-avatar" src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/user-default(1).png"/>
                                <div className="review-item-info"><span className="review-owner-name">ly_nguyen2345</span><span className="review-created-day">09/02/2020</span>
                                    <div className="review-desc">Dạ cho em hỏi mình mua gáo dừa ở đâu ạ</div>
                                </div>
                            </div>
                            <div className="recipe-review-item"><img className="review-owner-avatar" src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/user-default(2).png"/>
                                <div className="review-item-info"><span className="review-owner-name">Nguyễn
                                        Thủy</span><span className="review-created-day">06/12/2019</span>
                                    <div className="review-desc">Rất thích.👍</div>
                                </div>
                            </div>
                        </div><a className="view-more-comments" href="https://www.cooky.vn/cong-thuc/smoothie-xoai-chuoi-kiwi-smoothie-healthy-bowl-50880/danh-gia"><span>Xem
                                thêm bình luận</span></a>
                    </div>

                </div> 

               
                <div className="rr">
                    <div className="similar-recipes-wrap">
                        <h3 className="similar-recipes-title">Món ăn tương tự</h3>
                        <div className="similar-recipes">
                            <div className="similar-recipes-item"><a className="link-absolute" target="_blank" href="https://www.cooky.vn/cong-thuc/sinh-to-chuoi-xoai-11263"></a>
                                <div className="similar-recipe-total"><span>26</span><img src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/heart-white.svg"/>
                                </div>
                                <div className="similar-recipes-photo"><img className="img-fit" src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/recipe11263-635731854337623704.jpg"/>
                                </div><span className="similar-recipe-name">Sinh tố chuối xoài</span>
                                <div className="recipe-time"><span>Mẹ Múp</span>
                                    <div className="p-dot"></div> <span>10 phút</span>
                                </div>
                            </div>
                            <div className="similar-recipes-item"><a className="link-absolute" target="_blank" href="https://www.cooky.vn/cong-thuc/sinh-to-xoai-kiwi-11908"></a>
                                <div className="similar-recipe-total"><span>9</span><img src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/heart-white.svg"/>
                                </div>
                                <div className="similar-recipes-photo"><img className="img-fit" src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/recipe11908-636427268065712003.jpg"/>
                                </div><span className="similar-recipe-name">Sinh tố xoài kiwi</span>
                                <div className="recipe-time"><span>Lùn bất tử</span>
                                    <div className="p-dot"></div> <span>15 phút</span>
                                </div>
                            </div>
                            <div className="similar-recipes-item"><a className="link-absolute" target="_blank" href="https://www.cooky.vn/cong-thuc/sinh-to-kiwi-xoai-chuoi-32316"></a>
                                <div className="similar-recipe-total"><span>9</span><img src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/heart-white.svg"/>
                                </div>
                                <div className="similar-recipes-photo"><img className="img-fit" src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/cooky-recipe-cover-r32316.jpg"/>
                                </div><span className="similar-recipe-name">Sinh tố kiwi xoài chuối</span>
                                <div className="recipe-time"><span>Tiểu Đậu</span>
                                    <div className="p-dot"></div> <span>10 phút</span>
                                </div>
                            </div>
                            <div className="similar-recipes-item"><a className="link-absolute" target="_blank" href="https://www.cooky.vn/cong-thuc/sinh-to-kiwi-chuoi-sua-34879"></a>
                                <div className="similar-recipe-total"><span>5</span><img src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/heart-white.svg"/>
                                </div>
                                <div className="similar-recipes-photo"><img className="img-fit" src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/cooky-recipe-cover-r34879.jpg"/>
                                </div><span className="similar-recipe-name">Sinh tố kiwi chuối sữa</span>
                                <div className="recipe-time"><span>Bếp Ngon</span>
                                    <div className="p-dot"></div> <span>15 phút</span>
                                </div>
                            </div>
                            <div className="similar-recipes-item"><a className="link-absolute" target="_blank" href="https://www.cooky.vn/cong-thuc/sinh-to-xoai-chuoi-va-rau-cu-37570"></a>
                                <div className="similar-recipe-total"><span>9</span><img src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/heart-white.svg"/>
                                </div>
                                <div className="similar-recipes-photo"><img className="img-fit" src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/cooky-recipe-cover-r37570.jpg"/>
                                </div><span className="similar-recipe-name">Sinh tố xoài chuối và rau củ</span>
                                <div className="recipe-time"><span>Kim Khuyên</span>
                                    <div className="p-dot"></div> <span>15 phút</span>
                                </div>
                            </div>
                            <div className="similar-recipes-item"><a className="link-absolute" target="_blank" href="https://www.cooky.vn/cong-thuc/sinh-to-kiwi-dau-tay-43384"></a>
                                <div className="similar-recipe-total"><span>6</span><img src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/heart-white.svg"/>
                                </div>
                                <div className="similar-recipes-photo"><img className="img-fit" src="./Cách làm Smoothie Xoài Chuối Kiwi _ Ngon Hấp Dẫn _ Cooky_files/cooky-recipe-cover-r43384.jpg"/>
                                </div><span className="similar-recipe-name">Sinh tố kiwi dâu tây</span>
                                <div className="recipe-time"><span>Minh Tú</span>
                                    <div className="p-dot"></div> <span>25 phút</span>
                                </div>
                            </div>
                        </div>
                    </div><ins className="adsbygoogle" data-ad-client="ca-pub-9141160769841159" data-ad-slot="5911260551" data-ad-format="auto" data-full-width-responsive="true" style={{display: "block"}}></ins>
                </div> 

            </div>
        </div>
    </div>
    );
}