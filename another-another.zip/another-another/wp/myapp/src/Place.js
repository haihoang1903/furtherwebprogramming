import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Link, Route, Switch } from 'react-router-dom';
import { useHistory } from 'react-router-dom';
import { useRouteMatch } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Upload from './Upload';
function DisplayCustomerFoodChoice(prop) {
    let history = useHistory();
    const endpoint = "http://localhost:9000/customer/place/place/";
    const anotherendpoint = "http://localhost:9000/food/place/place/";
    const anotheranotherendpoint = "http://localhost:9000/customer/delete/list";
    const [value, setValue] = useState([]);
    const [value1, setValue1] = useState([]);
    const load = () => {
        fetch(endpoint + prop.display.id, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(fetchResult => {
                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                } else {
                    let list = [];
                    let list2 = [];
                    let counter = 0;
                    for (let i = 0; i < fetchResult[0].food.length; i++) {
                        if ("api" == fetchResult[0].food[i].provider) {
                            fetch(fetchResult[0].food[i].food_id)
                                .then(response2 => response2.json())
                                .then(fetchResult2 => {
                                    if (typeof fetchResult2 === "string" && "invalid token" == fetchResult2) {

                                    } else {
                                        list2.push({ id: fetchResult[0].food[i].food_id, result: fetchResult2 });
                                        if (fetchResult[0].food.length - 1 != counter) {
        
                                        } else {
                                            setValue(list);
                                            setValue1(list2);
                                        }
                                        counter++;
                                    }
                                    
                                })
                        } else {
                            fetch(anotherendpoint + fetchResult[0].food[i].food_id, {
                                method: "GET",
                                headers: {
                                    'Content-Type': 'application/json',
                                    'x-access-token': window.sessionStorage.getItem("token")
                                }
                            })
                                .then(response2 => response2.json())
                                .then(fetchResult2 => {
                                    if (typeof fetchResult2 === "string" && "invalid token" == fetchResult2) {

                                    } else {
                                        list.push(fetchResult2[0]);
                                    if (fetchResult[0].food.length - 1 != counter) {
    
                                    } else {
                                        setValue(list);
                                        setValue1(list2);
                                    }
                                    counter++;
                                    }
                                    
                                })
                        }
                    }
                }
                
            })
    }
    const del_element = (foodid, provider) => {
        fetch(anotheranotherendpoint, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({
                id: prop.display.id, food: {
                    food_id: foodid, provider: provider
                }
            })

        })
            .then(response => response.json())
            .then(fetchResult => {
                






                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                } else {
                    // prop.addId({id: prop.display.id});
                // history.push('/display');
                }
                // prop.addId({id: prop.display.id});
                // history.push('/display');

            });
    }
    /*
    return <div>
        <div className="row">{value.map((placesPlaces) => {
            fetch(anotherendpoint+placesPlaces)
            .then(response=>response.json())
            .then(fetchResult=>{
                return <div className="col"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src={fetchResult[0].image} alt="Card image cap" /><div className="card-body"><h5 className="card-title">{fetchResult[0].name}</h5><p className="card-text">{fetchResult[0].description}</p><button className="btn btn-primary" onClick={() => { window.sessionStorage.setItem("foodId", fetchResult[0].id); prop.addId({ id: prop.display.id }); history.push("/foodAdded"); }}>place</button></div></div></div>;
            })
    })}</div>

        <div className="row">{value1.map((placesPlaces) => {
            fetch(placesPlaces)
            .then(response=>response.json())
            .then(fetchResult=>{
                return <div className="col"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src={fetchResult.recipe.image} alt="Card image cap" /><div className="card-body"><h5 className="card-title">{fetchResult.recipe.label}</h5><button className="btn btn-primary" onClick={() => { window.sessionStorage.setItem("recipe_id", placesPlaces._links.self.href); prop.addId({ id: prop.display.id }); history.push("/displayData"); }}>place</button></div></div></div>;
            })
    })}</div>
    </div>;
    */
    useEffect(load, []);
    return <div>
        <div className="row">{value.map((placesPlaces) => {
            return <div className="col"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src={placesPlaces.image} alt="Card image cap" /><div className="card-body"><h5 className="card-title">{placesPlaces.name}</h5><p className="card-text">{placesPlaces.description}</p>
                <button className="btn btn-primary" onClick={() => { window.sessionStorage.setItem("foodId", placesPlaces.id); prop.addId({ id: prop.display.id }); history.push("/foodAdded"); }}>place</button>
                <div><form><button className="btn btn-primary" onClick={() => {
                    del_element(placesPlaces.id, 'customer'); prop.addId({ id: prop.display.id });
                    history.push('/display');
                }}>place</button></form></div></div></div></div>;
        })}</div>

        <div className="row">{value1.map((placesPlaces) => {
            return <div className="col"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src={placesPlaces.result.recipe.image} alt="Card image cap" /><div className="card-body"><h5 className="card-title">{placesPlaces.result.recipe.label}</h5><button className="btn btn-primary" onClick={() => { window.sessionStorage.setItem("recipe_id", placesPlaces.id); prop.addId({ id: prop.display.id }); history.push("/displayData"); }}>place</button><div><form><button className="btn btn-primary" onClick={() => {
                del_element(placesPlaces.id, 'api'); prop.addId({ id: prop.display.id });
                history.push('/display');
            }}>place</button></form></div></div></div></div>;
        })}</div>
    </div>;
}
function GetData(prop) {
    let history = useHistory();
    const [data, setData] = useState({});
    let default_data = [];
    let default_nutrient = [];
    var endPointfifth = "http://localhost:9000/comments/place";
    var endPointforth = "http://localhost:9000/customer/place/place" + "/" + prop.customer.id;
    var endPointthird = "http://localhost:9000/comments/all" + "/" + prop.display.id.split("/")[6].split("?")[0];
    const [value1, setValue1] = useState([]);
    const [input, setInput] = useState("");
    const endPoint = prop.display.id
    const endPointsecond = "http://localhost:9000/customer/add/list";
    const load = () => {
        if (undefined === prop.display.noDisplay) {
            fetch(endPoint)
                .then(response => response.json())
                .then(fetchResult => {
                    if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                    } else {
                        console.log("fetch",fetchResult);
                        setData(fetchResult.recipe);
                    }
                    
                });
        } else {
            history.push("/display");
        }
        /*
        console.log(linkReturn)
        console.log("finalData: ", recipeDataReturn)
        setRecipeDataReturn(recipeData)
/*
    link.map((data=>{
        fetched(data)
            .then(response=>response.json())
            .then(fetchResult=>{
                console.log("name", fetchResult)
            })
    }))*/
    }
    if (Object.keys(data).length != 0) {
        default_data = data.ingredients;
        default_nutrient = data.totalNutrients;
    }
    console.log("data", data.length)

    const addlist = () => {
        if (undefined === prop.customer.noDisplay) {
            fetch(endPointsecond, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    'x-access-token': window.sessionStorage.getItem("token")
                },
                body: JSON.stringify({ id: prop.customer.id, food: { food_id: prop.display.id, provider: "api" } })
            }).then(response => response.json())
                .then(fetchResult => { 
                    if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                    } else {

                    }
                })
        }
        else {
            history.push("/place");
        }
    }
    const loading = () => {
        fetch(endPointthird, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    console.log("test",data)
                let list = [];
                list = data;
                let count2 = 0;
                for (let i = 0; i < data.length; i++) {
                    fetch(endPointforth, {
                        method: "GET",
                        headers: {
                            'Content-Type': 'application/json',
                            'x-access-token': window.sessionStorage.getItem("token")
                        }
                    })
                        .then(rep => rep.json())
                        .then(data1 => {
                            if (typeof data1 === "string" && "invalid token" == data1) {

                            } else {
                                list[i]["customer"] = data1[0]
                                if (count2 != (data.length - 1)) {
    
                                } else {
                                    setValue1(list)
                                }
                                count2 = count2 + 1;
                            }
                            
                        })
                }
                }
                
            })
    }
    const loadLoad = () => {
        fetch(endPointfifth, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({ customerId: prop.customer.id, foodId: prop.display.id.split("/")[6].split("?")[0], text: input, date: new Date() })
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({id: prop.customer.id});
                    history.push("/displayData");
                }
                
            })

    }
    const loadloadload = () => {
        load();
        loading();
    }
    console.log("id",prop.display.id.split("/")[6].split("?")[0]);
    useEffect(loadloadload, [])

    return (<div>
        {prop.display.id}
        <div className="container-fluid" style={{ padding: "16px", minWidth: "1000px", width: "calc(100% - 190px * 2)", margin: "0 auto" }}>

            <div className="page-wrapper ">
                <div className="container recipe-detail-container ">
                    <div className="rm ">
                        <div className="recipe-main-photo"><img className="recipe-cover-photo" src={data.image} />
                        </div>
                        <div className="recipe-detail-content">


                            <h3 className="recipe-name">{data.label}</h3>



                            <div className="button-recipe"><span>346 Đã lưu</span><button className="btn btn-link" onClick={addlist}><img className="icon-like" /></button></div>




                            <div className="recipe-stats-info"><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="1" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="2" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="3" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="4" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="5" />
                                <span>9</span>
                                <div className="total-likes">
                                    <img src="https://www.cooky.vn/React/images/icons/heart.svg" /><span>346</span>
                                </div>

                                <div>
                                    <img src="https://www.cooky.vn/React/images/icons/view.svg" /><span>11k</span>
                                </div>

                            </div>



                            <div className="recipe-owner"><a href={data.url}>
                                <div className="recipe-owner-avatar"><img src="https://image.cooky.vn/usr/g10/96128/avt/s140/cooky-avatar-636959526416611860.jpg" />
                                </div>
                                <div className="recipe-owner-name">
                                    <h4><a href={data.url}>{data.source}</a></h4>
                                </div>
                            </a>
                                <div className="make-recipe-button"><img src="https://www.cooky.vn/React/images/icons/i-made-it-desktop.svg" /><span>I
                                    made it</span></div>
                            </div>

                            <div className="recipe-ingredient">
                                <h3>Ingredients</h3><span>Servings:{data.yield}</span>
                            </div>


                            <div id="ingredients-list">
                                {default_data.map((ingre) => {
                                    return <div className="ingredient-item"><span className="ingredient-name">{ingre.text}</span><span className="ingredient-quantity">{parseInt(ingre.weight)} Grams</span></div>;
                                })}
                            </div>



                            <div className="recipe-ads-banner-container">
                                <div className="banner-wrapper">
                                    <div className="banner animated-place-holder"></div>
                                </div>
                            </div>

                            <div className="recipe-steps-list">
                                <h3>Steps</h3>
                                <button><a href={data.url}>test</a></button>
                            </div>

                            <div className="recipe-ingredient">
                                <h3>Total Nutrients</h3><span></span>
                            </div>


                            <div id="ingredients-list">
                                {Object.values(default_nutrient).map((nutri) => {
                                    return <div className="ingredient-item"><span className="ingredient-name">{nutri.label}</span><span className="ingredient-quantity">{parseInt(nutri.quantity) + nutri.unit}</span></div>;
                                })}
                            </div>



                            <h3 className="how-to-make">Bình luận</h3>
                            <div className="recipe-comment-form-action">
                                <div className="user-avatar"><img
                                    src="https://cdn-icons-png.flaticon.com/512/149/149071.png" /></div>
                                <div className="form-content">
                                    <textarea className="recipe-description" placeholder="Comment" spellcheck="false" value={input} onChange={(e) => { setInput(e.target.value) }}></textarea>
                                    <div className="comment-btn-action"><form><button
                                        className="btn-submit-review" onClick={loadLoad}>Upload</button></form></div>
                                </div>
                            </div>
                            <div className="recipe-review">
                                {value1.map((placesPlaces) => {
                                    return <div className="recipe-review-item"><img className="review-owner-avatar" src="https://cdn-icons-png.flaticon.com/512/149/149071.png" />
                                        <div className="review-item-info"><span className="review-owner-name">{placesPlaces["customer"].firstName + " " + placesPlaces["customer"].lastName}</span><span className="review-created-day">{placesPlaces.date}</span>
                                            <div className="review-desc">{placesPlaces.text}</div>
                                        </div>
                                    </div>;
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>);
}
function getIndex(array, value) {
    var result = 0;
    if (0 != array.length) {
        for (let i = 0; i < array.length; ++i) {
            if (value == array[i].dietName) {
                result = i;
            }
        }
    } else {
        result = -1;
    }
    return result;
}
function Display({ addId }) {
    let history = useHistory();
    var endPoint = "http://localhost:9000/customer/placePlaceplace";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ customerName: "", customerPassword: "" });
    }
    const load = () => {
        fetch(endPoint + "/" + value.customerName + "/" + value.customerPassword)
            .then(response => response.json())
            .then(data => {
                if (undefined === data[0].invalid) {
                    window.sessionStorage.setItem("token", data[0].token);
                    window.sessionStorage.setItem("id", data[0].id);
                    addId({ id: data[0].id });
                } else {
                    console.log(data[0].invalid);
                }
            });
    };
    const placesPlacesplaces = () => {
        if (null === window.sessionStorage.getItem("id")) {
        } else {
            history.push("/display");
        }
    };
    useEffect(
        placesPlacesplaces
    );
    var places = <button type="submit" value="" className="button form-control" style={{ backgroundImage: "linear-gradient(-90deg, #f54f7c 0%, #f3413b 100%)", color: "white", marginBottom: "40px" }} onClick={(e) => { e.preventDefault(); load() }}>LOG IN</button>;
    return <div style={{ marginBottom: "10px", padding: "0px 25px" }}><input type="text" name="customer-name" id="customer-name" className="form-control button" value={value.customerName} onChange={(e) => { setValue({ customerName: e.target.value, customerPassword: value.customerPassword }) }} placeholder="Email" style={{ marginBottom: "20px" }} /><input type="password" name="customer-password" id="customer-password" className="form-control button" value={value.customerPassword} onChange={(e) => { setValue({ customerName: value.customerName, customerPassword: e.target.value }) }} placeholder="Password" />{places}</div>;
}
function Register() {
    let history = useHistory();
    var endPoint = "http://localhost:9000/customer/place";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ customerName: "", customerPassword: "", customerCustomerPassword: "" });
    }
    const load = () => {
        if (value.customerCustomerPassword != value.customerPassword) {
        } else {
            if (value.customerName == "" || value.customerPassword == "" || value.customerCustomerPassword == "") {
            } else {
                fetch(endPoint, {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ customerName: value.customerName, customerPassword: value.customerPassword })
                }).then(response => response.json())
                    .then(data => {
                        console.log(data);
                        if (undefined === data[0].invalid) {
                            history.push("/place");
                        } else {
                            console.log(data[0].invalid);
                        }
                    });
            }
        }
    };
    var places = <button type="submit" value="" className="button form-control" style={{ backgroundImage: "linear-gradient(-90deg, #f54f7c 0%, #f3413b 100%)", color: "white", marginBottom: "40px" }} onClick={(e) => { e.preventDefault(); load() }}>LOG IN</button>;
    return <div style={{ marginBottom: "10px", padding: "0px 25px" }}><input type="text" name="customer-name" id="customer-name" className="form-control button" value={value.customerName} onChange={(e) => { setValue({ customerName: e.target.value, customerPassword: value.customerPassword, customerCustomerPassword: value.customerCustomerPassword }) }} placeholder="Email" style={{ marginBottom: "20px" }} /><input type="password" name="customer-password" id="customer-password" className="form-control button" value={value.customerPassword} onChange={(e) => { setValue({ customerName: value.customerName, customerPassword: e.target.value, customerCustomerPassword: value.customerCustomerPassword }) }} placeholder="Password" style={{ marginBottom: "20px" }} /><input type="password" name="customer-customer-password" id="customer-customer-password" className="form-control button" value={value.customerCustomerPassword} onChange={(e) => { setValue({ customerName: value.customerName, customerPassword: value.customerPassword, customerCustomerPassword: e.target.value }) }} placeholder="Password" />{places}</div>;
}
function ResetPassword() {
    let history = useHistory();
    var endPoint = "http://localhost:9000/customers/reset/email";
    const [value, setValue] = useState("");
    const load = () => {
        
        fetch(endPoint, {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ customerName: value})
        }).then(response => response.json())
            .then(data => {
                console.log(data);
                if (undefined === data[0].invalid) {
                    history.push("/place");
                } else {
                    console.log(data[0].invalid);
                }
            });
    };
    var places = <button type="submit" value="" className="button form-control" style={{ backgroundImage: "linear-gradient(-90deg, #f54f7c 0%, #f3413b 100%)", color: "white", marginBottom: "40px" }} onClick={(e) => { e.preventDefault(); load() }}>LOG IN</button>;
    return <div style={{ marginBottom: "10px", padding: "0px 25px" }}><input type="text" name="customer-name" id="customer-name" className="form-control button" value={value} onChange={(e) => { setValue(e.target.value) }} placeholder="Email" style={{ marginBottom: "20px" }} /><input type="password" name="customer-password" id="customer-password" className="form-control button" placeholder="Password" style={{ marginBottom: "20px" }} /><input type="password" name="customer-customer-password" id="customer-customer-password" className="form-control button" placeholder="Password" />{places}</div>;
}


function ResetPassword2() {
    let history = useHistory();
    var endPoint = "http://localhost:9000/customers/verify/code";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ customerName: "", customerPassword: "",customerCustomerPassword: "",verificationCode: 0 });
    }
    const load = () => {
        if(value.customerPassword != value.customerCustomerPassword){

        }else{
            if(value.customerName == "" || value.customerPassword == "" || value.customerCustomerPassword == "" || value.verificationCode == 0){

            } else {
                fetch(endPoint, {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ customerName: value.customerName,customerPassword: value.customerPassword,verificationCode: parseInt(value.verificationCode)})
                }).then(response => response.json())
                    .then(data => {
                        console.log(data);
                        if (undefined === data[0].invalid) {
                            history.push("/place");
                        } else {
                            console.log(data[0].invalid);
                        }
                    });
            }
        }
        
    };
    var places = <button type="submit" value="" className="button form-control" style={{ backgroundImage: "linear-gradient(-90deg, #f54f7c 0%, #f3413b 100%)", color: "white", marginBottom: "40px" }} onClick={(e) => { e.preventDefault(); load() }}>LOG IN</button>;
    return <div style={{ marginBottom: "10px", padding: "0px 25px" }}><input type="text" name="verificationCode" id="verificationCode" className="form-control button" value={value.verificationCode} onChange={(e) => { setValue({ customerName: value.customerName, customerPassword: value.customerPassword,customerCustomerPassword: value.customerCustomerPassword,verificationCode: e.target.value }) }} placeholder="Email" style={{ marginBottom: "20px" }} /><input type="text" name="customer-name" id="customer-name" className="form-control button" value={value.customerName} onChange={(e) => { setValue({customerName: e.target.value, customerPassword: value.customerPassword,customerCustomerPassword: value.customerCustomerPassword,verificationCode: value.verificationCode})}} placeholder="Email" style={{ marginBottom: "20px" }} /><input type="password" name="customer-password" id="customer-password" className="form-control button" value={value.customerPassword} onChange={(e) => { setValue({customerName: value.customerName, customerPassword: e.target.value,customerCustomerPassword: value.customerCustomerPassword,verificationCode: value.verificationCode})}} placeholder="Password" style={{ marginBottom: "20px" }} /><input type="password" name="customer-customer-password" id="customer-customer-password" className="form-control button" value={value.customerCustomerPassword} onChange={(e) => { setValue({customerName: value.customerName, customerPassword: value.customerPassword,customerCustomerPassword: e.target.value,verificationCode: value.verificationCode})}} placeholder="Password" />{places}</div>;
}


function DisplayAndRegister({ addAddaddId }) {
    let { path, url } = useRouteMatch();
    return (
        <div className="container" style={{ paddingLeft: "300px", paddingRight: "300px" }}>
            <form className="datdaidi button">
                <div className="text-center" style={{ marginBottom: "20px", borderBottom: "solid", padding: "25px 0px", borderWidth: "thin" }}>
                    <div className="col " style={{ fontWeight: "bold", color: "#333333", display: "inline", marginRight: "50px" }}><a href={`${url}`}>Sign In</a></div>
                    <div className="col " style={{ fontWeight: "bold", color: "#333333", display: "inline", marginLeft: "50px" }}><a href={`${url}/register`}>Sign Up</a></div>
                    <div className="col " style={{ fontWeight: "bold", color: "#333333", display: "inline", marginRight: "50px" }}><a href={`${url}/reset`}>Forgot Password?</a></div>
                    <div className="col " style={{ fontWeight: "bold", color: "#333333", display: "inline", marginRight: "50px" }}><a href={`${url}/verify`}>Reset Password</a></div>
                </div>
                <div className="form-group">
                    <button className="form-control"
                        style={{ backgroundColor: "#4267b2", color: "#F3F3F3", textAlign: "start", marginBottom: "10px" }}><i
                            className="fa fa-facebook fa-fw" style={{ marginRight: "10px" }}></i>Sign in with
                        Facebook</button>
                    <button className="form-control"
                        style={{ backgroundColor: "#dd4b39", color: "#F3F3F3", textAlign: "start" }}><i
                            className="fa fa-google fa-fw" style={{ marginRight: "10px" }}>
                        </i>Sign in with
                        Google</button>
                </div>
                <div>
                    <p className="text-center">OR</p>
                    <p className="text-center">Sign In with Email</p>
                </div>
                <Switch>
                    <Route exact path={path}>
                        <Display addId={(id) => { addAddaddId(id) }} />
                    </Route>
                    <Route path={`${path}/register`}>
                        <Register />
                    </Route>
                    <Route path={`${path}/reset`}>
                        <ResetPassword />
                    </Route>
                    <Route path={`${path}/verify`}>
                        <ResetPassword2 />
                    </Route>
                </Switch>

            </form>
        </div>
    );
}
function DisplayPage() {
    return <div></div>;
}
function DisplayFoodAdded(prop) {
    let history = useHistory();
    var endPointfifth = "http://localhost:9000/comments/place";
    var endPointforth = "http://localhost:9000/customer/place/place" + "/" + prop.customer.id;
    var endPointthird = "http://localhost:9000/comments/all" + "/" + prop.display.id;
    var endPoint = "http://localhost:9000/food/place/place";
    const [value, setValue] = useState({ name: "", description: "", ingredients: [] });
    const [value1, setValue1] = useState([]);
    const [input, setInput] = useState("");
    const endPointsecond = "http://localhost:9000/customer/add/list";
    const load = () => {
        if (undefined === prop.display.noDisplay) {
            fetch(endPoint + "/" + prop.display.id, {
                method: "GET",
                headers: {
                    'Content-Type': 'application/json',
                    'x-access-token': window.sessionStorage.getItem("token")
                }
            })
                .then(response => response.json())
                .then(data => {
                    if (typeof data === "string" && "invalid token" == data) {

                    } else {
                        setValue(data[0]);
                    }
                    
                });
        } else {
            history.push("/display");
        }
    };
    const addlist = () => {
        if (undefined === prop.customer.noDisplay) {
            fetch(endPointsecond, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    'x-access-token': window.sessionStorage.getItem("token")
                },
                body: JSON.stringify({ id: prop.customer.id, food: { food_id: prop.display.id, provider: "customer" } })
            }).then(response => response.json())
                .then(fetchResult => { 
                    if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                    } else {
                        
                    }
                })
        }
        else {
            history.push("/place");
        }
    };
    const loading = () => {
        fetch(endPointthird, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    let list = [];
                    list = data;
                    let count2 = 0;
                    for (let i = 0; i < data.length; i++) {
                        fetch(endPointforth, {
                            method: "GET",
                            headers: {
                                'Content-Type': 'application/json',
                                'x-access-token': window.sessionStorage.getItem("token")
                            }
                        })
                            .then(rep => rep.json())
                            .then(data1 => {
                                if (typeof data1 === "string" && "invalid token" == data1) {

                                } else {
                                    list[i]["customer"] = data1[0]
                                    if (count2 != (data.length - 1)) {
        
                                    } else {
                                        setValue1(list)
                                    }
                                    count2 = count2 + 1;
                                }
                                
                            })
                    }
                }
                
            })
    }
    const loadLoad = () => {
        fetch(endPointfifth, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({ customerId: prop.customer.id, foodId: prop.display.id, text: input, date: new Date() })
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({ id: prop.customer.id })
                    history.push("/foodAdded");
                }
                
            })

    }
    const loadloadload = () => {
        load();
        loading();
    }
    useEffect(
        loadloadload
        , []);
    return (
        <div className="container-fluid" style={{ padding: "16px", minWidth: "1000px", width: "calc(100% - 190px * 2)", margin: "0 auto" }}>

            <div className="page-wrapper ">
                <div className="container recipe-detail-container ">
                    <div className="rm ">
                        <div className="breadcrumb ">
                            <ul>
                                <li className=" "><a href="https://www.cooky.vn/cong-thuc ">Công Thức</a></li>
                                <li className=" "><a href="https://www.cooky.vn/cach-lam/mon-sinh-to-nuoc-ep-ngon-d115 ">Sinh tố
                                    - Nước Ep</a></li>
                                <li className="active "><span>Smoothie xoài chuối kiwi - smoothie healthy bowl</span></li>
                            </ul>
                        </div>
                        <div className="recipe-main-photo"><img className="recipe-cover-photo" src={value.image} />
                        </div>
                        <div className="recipe-detail-content">


                            <h3 className="recipe-name">Smoothie xoài chuối kiwi - smoothie healthy bowl</h3>



                            <div className="button-recipe"><span>346 Đã lưu</span><button className="btn btn-link" onClick={addlist}><img className="icon-like" /></button></div>




                            <div className="recipe-stats-info"><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="1" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="2" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="3" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="4" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="5" />
                                <span>9</span>
                                <div className="total-likes">
                                    <img src="https://www.cooky.vn/React/images/icons/heart.svg" /><span>346</span>
                                </div>

                                <div>
                                    <img src="https://www.cooky.vn/React/images/icons/view.svg" /><span>11k</span>
                                </div>

                            </div>



                            <div className="recipe-owner"><a href="https://www.cooky.vn/thanh-vien/wenkimtuyen">
                                <div className="recipe-owner-avatar"><img src="https://image.cooky.vn/usr/g10/96128/avt/s140/cooky-avatar-636959526416611860.jpg" />
                                </div>
                                <div className="recipe-owner-name">
                                    <h4>BẾP THÁNG 12</h4><span>22 công thức, 1k người theo dõi</span>
                                </div>
                            </a>
                                <div className="make-recipe-button"><img src="https://www.cooky.vn/React/images/icons/i-made-it-desktop.svg" /><span>I
                                    made it</span></div>
                            </div>



                            <div className="recipe-desc-less">
                                <p>Smoothie Healthy Bowl là một món ăn sáng hỗ trợ giảm cân, chăm sóc sức đẹp phổ biến ở
                                    các nước Châu Âu và dần đang được ưa chuộng tại Việt Nam. Đây mà món ăn có thể giúp
                                    bạn thỏa sức sáng tạo với nhiều loại trái cây, các loại hạt khác nhau. Với vẻ ngoài
                                    vô cùng đẹp mắt và hương vị tươi mát, cách làm đơn giản, combo Smoothie Xoài Chuối
                                    Kiwi sẽ làm bạn thích thú.</p>
                            </div>
                            <div id="ingredients-list">
                                <div className="ingredient-item"><span className="ingredient-name">Chuối</span><span className="ingredient-quantity">400 Gr</span></div>
                            </div>



                            <div className="recipe-ads-banner-container">
                                <div className="banner-wrapper">
                                    <div className="banner animated-place-holder"></div>
                                </div>
                            </div>

                            <div className="recipe-steps-list">
                                <h3 className="how-to-make">Hướng dẫn thực hiện</h3>
                                <div className="cook-step-content">
                                    <div className="cook-step-item">
                                        <div className="step-number">1.</div>
                                        <div className="step-content">
                                            <p>Loại bỏ vỏ chuối, vỏ kiwi, vỏ xoài chín. Sau đó, cắt trái cây thành từng
                                                khoanh mỏng. Cho vào ngăn đá tủ lạnh ít nhất 2 tiếng.</p>
                                            <ul className="step-photos">
                                                <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102378373968618.png" />
                                                </li>
                                                <li><img src="https://image.cooky.vn/recipe/g6/50880/s240x240/cooky-recipe-637102378372508476.png" />
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <h3 className="how-to-make">Comments</h3>
                            <div className="recipe-comment-form-action">
                                <div className="user-avatar"><img
                                    src="https://cdn-icons-png.flaticon.com/512/149/149071.png" /></div>
                                <div className="form-content">
                                    <textarea className="recipe-description" placeholder="Comment" spellcheck="false" value={input} onChange={(e) => { setInput(e.target.value) }}></textarea>
                                    <div className="comment-btn-action"><form><button
                                        className="btn-submit-review" onClick={loadLoad}>Upload</button></form></div>
                                </div>
                            </div>
                            <div className="recipe-review">
                                {value1.map((placesPlaces) => {
                                    return <div className="recipe-review-item"><img className="review-owner-avatar" src="https://cdn-icons-png.flaticon.com/512/149/149071.png" />
                                        <div className="review-item-info"><span className="review-owner-name">{placesPlaces["customer"].firstName + " " + placesPlaces["customer"].lastName}</span><span className="review-created-day">{placesPlaces.date}</span>
                                            <div className="review-desc">{placesPlaces.text}</div>
                                        </div>
                                    </div>;
                                })}
                            </div>
                        </div>

                    </div>
                    </div>
            </div>
        </div>
    );
}
function DisplayCustomerFoodAdded(prop) {
    let history = useHistory();
    var endPoint = "http://localhost:9000/food/place/food";
    let endPoint2 = "http://localhost:9000/food/"
    const [value, setValue] = useState([]);
    const load = () => {
        fetch(endPoint + '/' + prop.display.id, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    setValue(data);
                }
                
            });
    };
    const deleteFood = (foodId) => {
        fetch(endPoint2 + foodId, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(fetchResult => {
                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                } else {
                    prop.addId({id: prop.display.id});
                    history.push("/display");
                }
                
            })
    }
    /*
const deleteFood=(foodId)=>{
    fetch(endPoint2+foodId,{
        method:"DELETE",
        headers:{
            "Content-Type": "application/json"
        }
    })
    .then(response=>response.json())
    .then(fetchResult=>{
        prop.addId({id: prop.display.id})
        history.push("/display")
    })
}
*/
    useEffect(
        load
        , []);
    return <div className="row">{value.map((placesPlaces) => {
        return <div className="col"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src="" alt="Card image cap" /><div className="card-body"><h5 className="card-title">{placesPlaces.name}</h5><p className="card-text">{placesPlaces.description}</p><button className="btn btn-primary" onClick={() => { window.sessionStorage.setItem("foodId", placesPlaces.id); prop.addId({ id: prop.display.id }); history.push("/foodAdded"); }}>place</button></div><div><button className="btn btn-info" onClick={() => { window.sessionStorage.setItem("foodId", placesPlaces.id); prop.addId({ id: prop.display.id }); history.push("/customerFoodUpdate"); }}>Yes</button></div>
            <div><button className="btn btn-info" onClick={() => { deleteFood(placesPlaces.id) }}>Delete</button></div></div></div>;
    })}</div>;
}
function DisplayCustomer(prop) {
    let { path, url } = useRouteMatch();
    let history = useHistory();
    var endPoint = "http://localhost:9000/customer/place/place";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ id: "", lastName: "", firstName: "", address: "", place: [] });
    }
    const load = () => {
        if (undefined === prop.display.noDisplay) {
            fetch(endPoint + "/" + prop.display.id, {
                method: "GET",
                headers: {
                    'Content-Type': 'application/json',
                    'x-access-token': window.sessionStorage.getItem("token")
                }
            })
                .then(response => response.json())
                .then(data => {
                    if (typeof data === "string" && "invalid token" == data) {

                    } else {
                        setValue(data[0]);
                    }
                    
                });
        } else {
            history.push("/place");
        }
    };
    const placesPlacesplaces = () => {
        prop.addId({ id: prop.display.id });
        history.push("/customerUpdate");
    };
    const customerFoodAdded = () => {
        prop.addId({ id: prop.display.id });
        history.push(`${url}/customerFoodAdded`);
    };
    const customerFoodDisplay = () => {
        prop.addId({ id: prop.display.id });
        history.push(`${url}/customerFoodDisplay`);
    };
    useEffect(
        load
        , []);
    return (
        <div className="container">
            <div className="row">
                <div className="col">
                    <div>
                        <img src="" alt="" />
                    </div>
                </div>
                <div className="col">
                    <div className="container">
                        <div className="row">
                            <div className="col">
                                Last name
                            </div>
                            <div className="col">
                                {value.lastName}
                            </div>
                        </div>
                        <div className="row">
                            <div className="col">
                                First name
                            </div>
                            <div className="col">
                                {value.firstName}
                            </div>
                        </div>
                        <div className="row">
                            <div className="col">
                                Address
                            </div>
                            <div className="col">
                                {value.address}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col" style={{ border: "none", padding: "0px" }}>
                    <div className="form-group">
                        <button className="form-control" style={{ border: "none", textDecoration: "none", borderBottom: "#111111 solid", borderRadius: "0px" }} onClick={placesPlacesplaces}>place</button>
                    </div>
                </div>
                <div className="col-0" style={{ width: "0px", padding: "0px" }}>
                </div>
            </div>
            <div className="row">
                <div className="col" style={{ border: "none", padding: "0px" }}>
                    <div className="form-group">
                        <button className="form-control" onClick={customerFoodAdded}>place</button>
                    </div>
                </div>
                <div className="col" style={{ border: "none", padding: "0px" }}>
                    <div className="form-group">
                        <button className="form-control" onClick={customerFoodDisplay}>place</button>
                    </div>
                </div>
            </div>
            <Route path={`${path}/customerFoodAdded`}>
                <DisplayCustomerFoodAdded display={prop.display} addId={(id) => { prop.addId(id) }} />
            </Route>
            <Route path={`${path}/customerFoodDisplay`}>
                <DisplayCustomerFoodChoice display={prop.display} addId={(id) => { prop.addId(id) }} />
            </Route>
        </div>
    );
}
function DisplayCustomerUpdate(prop) {
    let history = useHistory();
    var endPoint = "http://localhost:9000/customer/place/place";
    var endPointendPoint = "http://localhost:9000/customer/place/place/place";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ id: "", lastName: "", firstName: "", address: "" });
    }
    const load = () => {
        if (undefined === prop.display.noDisplay) {
            fetch(endPoint + "/" + prop.display.id, {
                method: "GET",
                headers: {
                    'Content-Type': 'application/json',
                    'x-access-token': window.sessionStorage.getItem("token")
                }
            })
                .then(response => response.json())
                .then(data => {
                    if (typeof data === "string" && "invalid token" == data) {

                    } else {
                        setValue({ id: data[0].id, lastName: data[0].lastName, firstName: data[0].firstName, address: data[0].address });
                    }
                });
        } else {
            history.push("/place");
        }
    };
    const placesPlacesplaces = () => {
        fetch(endPointendPoint, {
            method: "PUT",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify(value)
        }).then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({ id: prop.display.id });
                    history.push("/display");
                }
                
            });
    };
    useEffect(
        load
        , []);
    return <div className="container"><div className="row"><div className="col">Last name</div><div className="col"><div className="form-group"><input type="text" id="lastName" name="lastName" className="form-control" value={value.lastName} onChange={(e) => { setValue({ id: value.id, lastName: e.target.value, firstName: value.firstName, address: value.address }) }} /></div></div></div><div className="row"><div className="col">First name</div><div className="col"><div className="form-group"><input type="text" id="firstName" name="firstName" className="form-control" value={value.firstName} onChange={(e) => { setValue({ id: value.id, lastName: value.lastName, firstName: e.target.value, address: value.address }) }} /></div></div></div><div className="row"><div className="col">Address</div><div className="col"><div className="form-group"><input type="text" id="address" name="address" className="form-control" value={value.address} onChange={(e) => { setValue({ id: value.id, lastName: value.lastName, firstName: value.firstName, address: e.target.value }) }} /></div></div></div><div className="row"><div className="form-group"><button className="form-control" onClick={placesPlacesplaces}>place</button></div></div></div>;
}
function DisplayPlaces(prop) {
    const load = () => {
        if (null === window.sessionStorage.getItem("id")) {
            prop.deleteId({ noDisplay: "No Display" });
        } else {
            window.sessionStorage.removeItem("id");
            prop.deleteId({ noDisplay: "No Display" });
        }
    };
    var places = <div></div>;
    if (undefined === prop.display.noDisplay) {
        places = <div className="dropdown" style={{ display: "inline-block", marginLeft: "10px" }}><button className="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Display</button><div className="dropdown-menu" aria-labelledby="dropdownMenu2"><a className="dropdown-item" href="/customerPlace">Action</a><a className="dropdown-item" href="/customerFood">Action</a><a className="dropdown-item" href="/place" onClick={load}>Something else here</a></div></div>;
    } else {
        places = <a className="btn btn-outline-light" style={{ marginLeft: "10px" }} href="/place" onClick={load}>Place</a>;
    }
    return <div><a href="/place" className="action extra n-btn" title="Bộ sưu tập" target="_self"><img className="icon" src="	https://www.cooky.vn/React/Images/Icons/heart-big-white.svg" /></a><a className="btn btn-outline-light" style={{ marginLeft: "10px" }} href="/place">113</a>{places}</div>;
}
/** 
  <!-- <div class="dropdown d-inline-flex p-2">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              Dropdown button
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
              <div>
                <a class="dropdown-item" href="#">Action</a>
              </div>
              <div>
                <a class="dropdown-item" href="#">Another action</a>
              </div>
              <div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </div>
          </div> -->
    <button className="btn btn-outline-light " style={{marginLeft: "10px"}}>113</button>
              <button className="btn btn-outline-light " style={{marginLeft: "10px"}}>Dang Nhap</button>
 **/
function List(prop) {
    const [recipeDataReturn, setRecipeDataReturn] = useState([])
    const [termReturn, setTermReturn] = useState("")
    const [nextEndPointReturn, setNextEndPointReturn] = useState("")
    const [userRecipeReturn, setUserRecipeReturn] = useState([])
    const [cal, setCal] = useState({ from: "", to: "" });
    const [diet, setDiet] = useState([]);
    const [health, setHealth] = useState([]);
    let recipeData = []
    let fetched = []
    let nEndP = ""
    let calories = ""
    let diets = ""
    let healths = ""
    if (cal.from != "" && cal.to == "") {
        calories = "&calories=" + cal.from + "+";
    } else if (cal.from != "" && cal.to != "") {
        calories = "&calories=" + cal.from + "-" + cal.to;
    } else if (cal.from == "" && cal.to != "") {
        calories = "&calories=" + cal.to;
    } else {
        calories = "";
    }
    for (let i = 0; i < diet.length; i++) {
        diets = diets + "&diet=" + diet[i];
    }
    console.log(diet)
    console.log(healths)
    const checkbox = (e) => {
        let data = diet;
        if (e.target.checked) {
            data.push(e.target.value);
        } else {
            data.indexOf(e.target.value);
            data.splice(data.indexOf(e.target.value), 1);
        }
        console.log(data)
        setDiet(data)

    }
    for (let i = 0; i < health.length; i++) {
        healths = healths + "&health=" + health[i];
    }
    const checkboxHealth = (e) => {
        let data = health;
        if (e.target.checked) {
            data.push(e.target.value);
        } else {
            data.indexOf(e.target.value);
            data.splice(data.indexOf(e.target.value), 1);
        }
        console.log(data)
        setHealth(data)

    }
    const endPoint = "https://api.edamam.com/api/recipes/v2?type=public&q=" + prop.valueDisplay + "&app_id=fe1da2d2&app_key=%2006a4dadc3c947a1b4b7a0e15622cb4fe" + calories + diets
    const endPoint2 = "http://localhost:9000/food/search/" + prop.valueDisplay
    const load = () => {
        fetch(endPoint)
            .then(response => response.json())
            .then(fetchResult => {
                window.sessionStorage.removeItem("value")
                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                } else {
                    fetched = fetchResult.hits;
                    nEndP = fetchResult._links.next.href
                    fetch(endPoint2)
                        .then(response2 => response2.json())
                        .then(fetchResult2 => {
                            if (typeof fetchResult2 === "string" && "invalid token" == fetchResult2) {

                            } else {
                                setUserRecipeReturn(fetchResult2)
                            setRecipeDataReturn(fetched)
                            setNextEndPointReturn(nEndP)
                            }
                            
    
                        })
                }
                
            })
        /*
        console.log(linkReturn)
        console.log("finalData: ", recipeDataReturn)
        setRecipeDataReturn(recipeData)
/*
    link.map((data=>{
        fetched(data)
            .then(response=>response.json())
            .then(fetchResult=>{
                console.log("name", fetchResult)
            })
    }))*/
    }
    console.log("data123: ", userRecipeReturn);
    const next = () => {
        fetch(nextEndPointReturn)
            .then(response => response.json())
            .then(fetchResult => {
                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {
                    
                } else {
                    nEndP = fetchResult._links.next.href
                setNextEndPointReturn(nEndP)
                let storedNextRecipes = [];
                let storedRecipes = [];
                let concat = [];
                storedNextRecipes = fetchResult.hits;
                console.log("new", storedNextRecipes)
                storedRecipes = recipeDataReturn;
                concat = storedRecipes.concat(storedNextRecipes);
                setRecipeDataReturn(concat)
                }
                
            })
    }
    console.log(recipeDataReturn.length);
    /*useEffect(()=>{load()},[])*/
    useEffect(() => {
        if (null == window.sessionStorage.getItem("value")) {
        } else {
            load();
        }
    })
    return (
        <div>
            <section>
                <div className="nav-item dropdown megamenu"><a id="megamneu" href="" data-toggle="dropdown" aria-haspopup="true"
                    aria-expanded="false" className="nav-link dropdown-toggle font-weight-bold text-uppercase text-center">Mega
                    Menu</a>
                    <div aria-labelledby="megamneu" className="dropdown-menu border-0 p-0 m-0">
                        <div className="container">
                            <div className="row bg-white rounded-0 m-0 shadow-sm">
                                <div className="col">
                                    <div className="p-4">
                                        <div className="row">
                                            <div className="col-2">
                                                <h6 className="font-weight-bold text-uppercase">Calories</h6>
                                                <div className="form-group row ">
                                                    <label for="StartingCal" className="col-sm-3 col-form-label">From</label>
                                                    <div className="col-sm-10">
                                                        <input type="text" className="form-control w-50" id="StartingCal" value={cal.from} onChange={(e) => {
                                                            setCal({ from: e.target.value, to: cal.to })
                                                        }} />
                                                    </div>
                                                </div>
                                                <div className="form-group row ">
                                                    <label for="EndCal" className="col-sm-3 col-form-label">To</label>
                                                    <div className="col-sm-10">
                                                        <input type="text" className="form-control w-50" id="EndCal" value={cal.to} onChange={(e) => {
                                                            setCal({ from: cal.from, to: e.target.value })
                                                        }} />
                                                    </div>
                                                </div>
                                                <p style={{ fontWeight: "bold;" }}>Ingredient</p>
                                                <div className="form-group row ">
                                                    <label for="Ingredient" className="col-sm-5 col-form-label">Up to</label>
                                                    <div className="col-sm-10">
                                                        <input type="text" className="form-control w-50" id="Ingredient" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-5">
                                                <h6 className="font-weight-bold text-uppercase">Diet</h6>
                                                <div className="row">
                                                    <ul className="col" style={{ listStyleType: "none", padding: "0%" }}>
                                                        <li className="itm">
                                                            <input type="checkbox" value="vegetarian" name="health" onChange={checkboxHealth} />
                                                            <label>Vegetarian</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="vegan" name="health" onChange={checkboxHealth} />
                                                            <label>Vegan</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="paleo" name="health" onChange={checkboxHealth} />
                                                            <label>Paleo</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="high-fiber" name="diet" onChange={checkbox} />
                                                            <label>High-Fiber</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="high-protein" name="diet" onChange={checkbox} />
                                                            <label>High-Protein</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-carb" name="diet" onChange={checkbox} />
                                                            <label>Low-Carb</label>
                                                        </li>
                                                    </ul>
                                                    <ul className="col" style={{ listStyleType: "none", padding: "0%" }}>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-fat" name="diet" onChange={checkbox} />
                                                            <label>Low-Fat</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-sodium" name="diet" onChange={checkbox} />
                                                            <label>Low-Sodium</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="sugar-conscious" name="health" onChange={checkboxHealth} />
                                                            <label>Low-Sugar</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="alcohol-free" name="health" onChange={checkboxHealth} />
                                                            <label>Alcohol-Free</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="balanced" name="diet" onChange={checkbox} />
                                                            <label>Balanced</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="immuno-supportive" name="health" onChange={checkboxHealth} />
                                                            <label>Immunity</label>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div className="col-4">
                                                <h6 className="font-weight-bold text-uppercase">Alergies</h6>
                                                <div className="row">
                                                    <ul className="col" style={{ listStyleType: "none", padding: "0%" }}>
                                                        <li className="itm">
                                                            <input type="checkbox" value="vegetarian" name="health" onChange={checkboxHealth} />
                                                            <label>Vegetarian</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="vegan" name="health" onChange={checkboxHealth} />
                                                            <label>Vegan</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="paleo" name="health" onChange={checkboxHealth} />
                                                            <label>Paleo</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="high-fiber" name="diet" onChange={checkbox} />
                                                            <label>High-Fiber</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="high-protein" name="diet" onChange={checkbox} />
                                                            <label>High-Protein</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-carb" name="diet" onChange={checkbox} />
                                                            <label>Low-Carb</label>
                                                        </li>
                                                    </ul>
                                                    <ul className="col" style={{ listStyleType: "none", padding: "0%" }}>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-fat" name="diet" onChange={checkbox} />
                                                            <label>Low-Fat</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-sodium" name="diet" onChange={checkbox} />
                                                            <label>Low-Sodium</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="sugar-conscious" name="health" onChange={checkboxHealth} />
                                                            <label>Low-Sugar</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="alcohol-free" name="health" onChange={checkboxHealth} />
                                                            <label>Alcohol-Free</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="balanced" name="diet" onChange={checkbox} />
                                                            <label>Balanced</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="immuno-supportive" name="health" onChange={checkboxHealth} />
                                                            <label>Immunity</label>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section style={{ paddingLeft: "500px", paddingRight: "400px", paddingTop: "10px", paddingBottom: "10px" }}>
                <div className="container-fluid">
                    <div className="home-top-box" style={{ marginBottom: "20px" }}>
                        <div className="headline" style={{ marginBottom: "#000054 solid;" }}>
                            <h2>Results</h2>
                        </div>
                    </div>
                    <div className="row">
                        {userRecipeReturn.map((data) => {
                            return <div className="col">
                                <div className="card" style={{ width: "12rem", border: "none", borderRadius: "2px" }}>
                                    <img className="card-img-top" src={data.image} alt="Card image cap" style={{ borderRadius: "5px" }} />
                                    <div className="card-body">
                                        <a>{data.name}</a>
                                    </div>
                                </div>
                            </div>;
                        })}
                    </div>
                </div>
            </section>
            <section style={{ paddingLeft: "500px", paddingRight: "400px", paddingTop: "10px", paddingBottom: "10px" }}>
                <div className="container-fluid">
                    <div className="home-top-box" style={{ marginBottom: "20px" }}>
                        <div className="headline" style={{ marginBottom: "#000054 solid;" }}>
                            <h2>Results</h2>
                        </div>
                    </div>
                    <div className="row">
                        {recipeDataReturn.map((data) => {
                            return <div className="col">
                                <div className="card" style={{ width: "12rem", border: "none", borderRadius: "2px" }}>
                                    <img className="card-img-top" src={data.recipe.image} alt="Card image cap" style={{ borderRadius: "5px" }} />
                                    <div className="card-body">
                                        <a href="/displayData" className="card-title" style={{ color: "black" }} onClick={() => {
                                            window.sessionStorage.setItem("recipe_id", data._links.self.href)
                                        }}>{data.recipe.label}</a>
                                    </div>
                                </div>
                            </div>;
                        })}
                    </div>
                </div>
            </section>
            <a><button onClick={() => next()}>more</button></a>
        </div>
    )
}
/*
    
*/
function DisplayCustomerFood(prop) {
    let history = useHistory();
    var endPoint = "http://localhost:9000/food/place/place";
    const [selectedFile, setSelectedFile] = useState(null);
    const [ingredients, setIngredients] = useState({ added: [] });
    const [foodDiet, setFoodDiet] = useState({ added: [] });
    const [steps, setSteps] = useState({ added: [] });
    const [value, setValue] = useState({ added: [{ foodName: "", foodCalories: 0, foodDescription: "" }] });
    var dietValues = ["Vegetarian", "Vegan", "Paleo", "High-Fiber", "High-Protein", "Low-Carb", "Low-Fat", "Low-Sodium", "Low-Sugar", "Alcohol-Free", "Balanced", "Immunity"];
    var count = -1;
    var countCountcountCount = -1;
    var source = "";
    var slice1 = "";
    if (selectedFile === null) {

    } else {
        source = selectedFile.profileImg
        console.log("source", slice1)
    }
    var imageHandler = (e) => {
        const reader = new FileReader();
        reader.onload = () => {
            if (reader.readyState === 2) {
                setSelectedFile({ profileImg: reader.result })
            }
        }
        reader.readAsDataURL(e.target.files[0])
    };
    const load = () => {
        fetch(endPoint, {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({ name: value.added[0].foodName, description: value.added[0].foodDescription, image: source, ingredients: ingredients.added, diet: foodDiet.added, steps: steps.added, calories: value.added[0].foodCalories, customerId: prop.display.id })
        }).then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({ id: prop.display.id });
                    history.push("/display");
                }
                
            });
    };
    const placesPlacesplaces = () => {
        var ingredientValues = ingredients.added;
        ingredientValues.push({ ingredientName: "", ingredientNum: 0, ingredientLast: "" });
        setIngredients({ added: ingredientValues });
    };
    const placesPlacesplacesPlaces = () => {
        var stepValues = steps.added;
        stepValues.push({ stepNum: steps.added.length, stepDetail: "" });
        setSteps({ added: stepValues });
    };
    const idPlacesplacesPlaces = () => {
        if (undefined === prop.display.noDisplay) {
        } else {
            history.push("/place");
        }
    };
    useEffect(
        idPlacesplacesPlaces
    );
    return (
        <div>
            <section
                style={{
                    paddingLeft: "500px",
                    paddingRight: "400px",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                }}
            >
                <div className="container">
                    <div className="text-center form-group">
                        <span className="display-4">Tạo mới và chia sẻ công thức</span>
                    </div>
                    <div className="form-group">
                        <img src={source} width="400px" />
                        <input type="file" className="" onChange={imageHandler}></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control" value={value.added[0].foodName} onChange={(e) => { setValue({ added: [{ foodName: e.target.value, foodCalories: value.added[0].foodCalories, foodDescription: value.added[0].foodDescription }] }) }}
                            placeholder="Enter the name of the recipe"
                        ></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control" value={value.added[0].foodDescription} onChange={(e) => { setValue({ added: [{ foodName: value.added[0].foodName, foodCalories: value.added[0].foodCalories, foodDescription: e.target.value }] }) }}
                            placeholder="Short description of the recipe"
                        ></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control"
                            placeholder=""
                        ></input>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Ingredient</h3>
                        {ingredients.added.map((placesPlaces) => {
                            count = count + 1;
                            var index = count;
                            var ingredient = <div className="row"><div className="col"><label>Name of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientName} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientName = e.target.value; setIngredients({ added: ingredientsPlaces }); }}></input></div><div className="col"><label>Amount of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientNum} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientNum = parseInt(e.target.value); setIngredients({ added: ingredientsPlaces }); }}></input></div><div className="col"><label>Last Place of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientLast} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientLast = e.target.value; setIngredients({ added: ingredientsPlaces }); }}></input></div></div>;
                            return ingredient;
                        })}
                    </div>
                    <div className="form-group">
                        <button className="btn btn-outline-primary" onClick={placesPlacesplaces}>+</button>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Calories</h3>
                        <input type="text" className="form-control w-50" value={value.added[0].foodCalories} onChange={(e) => { setValue({ added: [{ foodName: value.added[0].foodName, foodCalories: parseInt(e.target.value), foodDescription: value.added[0].foodDescription }] }) }}></input>
                        <div className="form-group">
                            <h3 style={{ fontWeight: "bold" }}>Diet</h3>
                            <ul className="row" style={{ marginLeft: "1px", listStyleType: "none" }}>
                                {dietValues.map((placesPlaces) => {
                                    var diet = <div className="col-6"><li className="itm"><input type="checkbox" value={placesPlaces} onChange={(e) => { var dietPlaces = foodDiet.added; if (!e.target.checked) { dietPlaces.splice(getIndex(dietPlaces, e.target.value), 1) } else { dietPlaces.push({ dietName: e.target.value }); }; setFoodDiet({ added: dietPlaces }); }} name="health" /><label>{placesPlaces}</label></li></div>;
                                    return diet;
                                })}
                            </ul>
                        </div>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Steps</h3>
                        {steps.added.map((placesPlaces) => {
                            countCountcountCount = countCountcountCount + 1;
                            var index = countCountcountCount;
                            var step = <div><input type="text" className="form-control" value={steps.added[index].stepDetail} onChange={(e) => { var stepsPlaces = steps.added; stepsPlaces[index].stepDetail = e.target.value; setSteps({ added: stepsPlaces }); }}></input></div>;
                            return step;
                        })}
                    </div>
                    <div>
                        <button className="btn btn-outline-primary" onClick={placesPlacesplacesPlaces}>+ more steps</button>
                    </div>
                    <div>
                        <button className="btn btn-outline-primary" onClick={load}>place</button>
                    </div>
                </div>
            </section>
        </div>
    );
}
function DisplayCustomerFoodUpdate(prop) {
    let history = useHistory();
    var endPoint = "http://localhost:9000/food/place/place" + "/" + prop.foodValue.id;
    var endpoint2 = "http://localhost:9000/food/update/display";
    const [selectedFile, setSelectedFile] = useState(null);
    const [ingredients, setIngredients] = useState({ added: [] });
    const [foodDiet, setFoodDiet] = useState({ added: [] });
    const [steps, setSteps] = useState({ added: [] });
    const [value, setValue] = useState({ added: [{ foodName: "", foodCalories: 0, foodDescription: "" }] });
    var dietValues = ["Vegetarian", "Vegan", "Paleo", "High-Fiber", "High-Protein", "Low-Carb", "Low-Fat", "Low-Sodium", "Low-Sugar", "Alcohol-Free", "Balanced", "Immunity"];
    var count = -1;
    var countCountcountCount = -1;
    var source = "";
    var slice1 = "";
    if (selectedFile === null) {

    } else {
        source = selectedFile.profileImg
        console.log("source", slice1)
    }
    var imageHandler = (e) => {
        const reader = new FileReader();
        reader.onload = () => {
            if (reader.readyState === 2) {
                setSelectedFile({ profileImg: reader.result })
            }
        }
        reader.readAsDataURL(e.target.files[0])
    };
    const load = () => {
        fetch(endPoint, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    setIngredients({ added: data[0].ingredients });
                setFoodDiet({ added: data[0].diet });
                setSteps({ added: data[0].steps });
                setValue({ added: [{ foodName: data[0].name, foodCalories: data[0].calories, foodDescription: data[0].description }] });
                setSelectedFile({ profileImg: data[0].image });
                }
                
            });
    };
    const updateFood = () => {
        fetch(endpoint2, {
            method: "PUT",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({ id: prop.foodValue.id, name: value.added[0].foodName, description: value.added[0].description, ingredients: ingredients.added, image: selectedFile.profileImg, diet: foodDiet.added, steps: steps.added, calories: value.added[0].foodCalories, customerId: prop.display.id })
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({id:prop.display.id});
                    history.push("/customerPlace");
                }
            });
    }
    const placesPlacesplaces = () => {
        var ingredientValues = ingredients.added;
        ingredientValues.push({ ingredientName: "", ingredientNum: 0, ingredientLast: "" });
        setIngredients({ added: ingredientValues });
    };
    const placesPlacesplacesPlaces = () => {
        var stepValues = steps.added;
        stepValues.push({ stepNum: steps.added.length, stepDetail: "" });
        setSteps({ added: stepValues });
    };
    const idPlacesplacesPlaces = () => {
        if (undefined === prop.display.noDisplay) {
            load();
        } else {
            history.push("/place");
        }
    };
    const healthArr = [];
    for (let i = 0; i < foodDiet.added.length; i++) {
        healthArr.push(foodDiet.added[i].dietName);
    }
    useEffect(
        idPlacesplacesPlaces, []
    );
    return (
        <div>
            <section
                style={{
                    paddingLeft: "500px",
                    paddingRight: "400px",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                }}
            >
                <div className="container">
                    <div className="text-center form-group">
                        <span className="display-4">Tạo mới và chia sẻ công thức</span>
                    </div>
                    <div className="form-group">
                        <img src={source} width="400px" />
                        <input type="file" className="" onChange={imageHandler}></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control" value={value.added[0].foodName} onChange={(e) => { setValue({ added: [{ foodName: e.target.value, foodCalories: value.added[0].foodCalories, foodDescription: value.added[0].foodDescription }] }) }}
                            placeholder="Enter the name of the recipe"
                        ></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control" value={value.added[0].foodDescription} onChange={(e) => { setValue({ added: [{ foodName: value.added[0].foodName, foodCalories: value.added[0].foodCalories, foodDescription: e.target.value }] }) }}
                            placeholder="Short description of the recipe"
                        ></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control"
                            placeholder=""
                        ></input>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Ingredient</h3>
                        {ingredients.added.map((placesPlaces) => {
                            count = count + 1;
                            var index = count;
                            var ingredient = <div className="row"><div className="col"><label>Name of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientName} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientName = e.target.value; setIngredients({ added: ingredientsPlaces }); }}></input></div><div className="col"><label>Amount of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientNum} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientNum = parseInt(e.target.value); setIngredients({ added: ingredientsPlaces }); }}></input></div><div className="col"><label>Last Place of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientLast} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientLast = e.target.value; setIngredients({ added: ingredientsPlaces }); }}></input></div></div>;
                            return ingredient;
                        })}
                    </div>
                    <div className="form-group">
                        <button className="btn btn-outline-primary" onClick={placesPlacesplaces}>+</button>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Calories</h3>
                        <input type="text" className="form-control w-50" value={value.added[0].foodCalories} onChange={(e) => { setValue({ added: [{ foodName: value.added[0].foodName, foodCalories: parseInt(e.target.value), foodDescription: value.added[0].foodDescription }] }) }}></input>
                        <div className="form-group">
                            <h3 style={{ fontWeight: "bold" }}>Diet</h3>
                            <ul className="row" style={{ marginLeft: "1px", listStyleType: "none" }}>
                                {dietValues.map((placesPlaces) => {
                                    let state = ""
                                    if (healthArr.includes(placesPlaces)) {
                                        state = "true"
                                    } else {
                                        state = ""
                                    }
                                    var diet = <div className="col-6"><li className="itm"><input type="checkbox" checked={state} value={placesPlaces} onChange={(e) => { var dietPlaces = foodDiet.added; if (!e.target.checked) { dietPlaces.splice(getIndex(dietPlaces, e.target.value), 1) } else { dietPlaces.push({ dietName: e.target.value }); }; setFoodDiet({ added: dietPlaces }); }} name="health" /><label>{placesPlaces}</label></li></div>;
                                    console.log(state);
                                    return diet;
                                })}
                            </ul>
                        </div>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Steps</h3>
                        {steps.added.map((placesPlaces) => {
                            countCountcountCount = countCountcountCount + 1;
                            var index = countCountcountCount;
                            var step = <div><input type="text" className="form-control" value={steps.added[index].stepDetail} onChange={(e) => { var stepsPlaces = steps.added; stepsPlaces[index].stepDetail = e.target.value; setSteps({ added: stepsPlaces }); }}></input></div>;
                            return step;
                        })}
                    </div>
                    <div>
                        <button className="btn btn-outline-primary" onClick={placesPlacesplacesPlaces}>+ more steps</button>
                    </div>
                    <div>
                        <button className="btn btn-outline-primary" onClick={updateFood}>place</button>
                    </div>
                </div>
            </section>
        </div>
    );
}
function DisplayPlacesPlacesPlaces(prop) {
    let history = useHistory();
    const load = () => {
        window.sessionStorage.setItem("value", 0);
        if (0 == prop.valueDoNotShow) {
            prop.addValueDoNotDisplay(1);
        } else {
            prop.addValueDoNotDisplay(0);
        }
        history.push("/list");
    }
    return <div style={{ display: "inline-block" }}><button className="btn btn-primary" onClick={load}>place</button></div>;
}
function Place() {
    const [value, setValue] = useState({});
    const [valueReturn, setValueReturn] = useState("");
    const [valueDoNotDisplay, setValueDoNotDisplay] = useState(0);
    if (0 != Object.keys(value).length) {
    } else {
        if (null === window.sessionStorage.getItem("id")) {
            setValue({ noDisplay: "No Display" });
        } else {
            setValue({ id: window.sessionStorage.getItem("id") });
        }
    }
    var foodId = {};
    if (null === window.sessionStorage.getItem("foodId")) {
        foodId = { noDisplay: "No Display" };
    } else {
        foodId = { id: window.sessionStorage.getItem("foodId") };
    }
    const [food, setFood] = useState(foodId);
    var recipeId = {};
    if (null === window.sessionStorage.getItem("recipe_id")) {
        recipeId = { noDisplay: "No Display" };
    } else {
        recipeId = { id: window.sessionStorage.getItem("recipe_id") }
    }
    return (
        <Router>
            <nav className="navbar navbar-light " style={{ backgroundColor: "#e60028" }}>
                <div className="container">
                    <form className="d-flex">
                        <img src="https://www.cooky.vn/React/Images/Logos/logo.svg" alt="" />
                        <input className="form-control me-2" onChange={(e) => { setValueReturn(e.target.value) }} value={valueReturn} type="search" placeholder="Search" aria-label="Search"
                            style={{ marginLeft: "10px" }} />
                    </form>
                    <DisplayPlacesPlacesPlaces valueDoNotShow={valueDoNotDisplay} addValueDoNotDisplay={(valueDoNotShow) => { setValueDoNotDisplay(valueDoNotShow) }} />
                    <DisplayPlaces display={value} deleteId={(noDisplay) => { setValue(noDisplay) }} />
                </div>
            </nav>
            <section id="place">
                <Switch>
                    <Route path="/place">
                        <DisplayAndRegister addAddaddId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/display">
                        <DisplayPage />
                    </Route>
                    <Route path="/list">
                        <List valueDisplay={valueReturn} />
                    </Route>
                    <Route path="/customerPlace">
                        <DisplayCustomer display={value} addId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/foodAdded">
                        <DisplayFoodAdded display={foodId} customer={value} addId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/customerUpdate">
                        <DisplayCustomerUpdate display={value} addId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/customerFood">
                        <DisplayCustomerFood display={value} addId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/displayData">
                        <GetData display={recipeId} customer={value} addId={(id) => { setValue(id) }}  />
                    </Route>
                    <Route path="/customerFoodUpdate">
                        <DisplayCustomerFoodUpdate display={value} foodValue={foodId} addId={(id) => { setValue(id) }} />
                    </Route>
                </Switch>
            </section>
            <footer style={{ backgroundColor: "#F3F3F3" }}>
                <a href="/about">About Us</a>
            </footer>
        </Router>
    );
}
export default Place;
