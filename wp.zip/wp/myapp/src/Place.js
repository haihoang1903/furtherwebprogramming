import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Link, Route, Switch } from 'react-router-dom';
import { useHistory } from 'react-router-dom';
import { useRouteMatch } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Upload from './Upload';
function DisplayCustomerFoodChoice(prop) {
    let history = useHistory();
    const endpoint = "/customer/place/place/";
    const anotherendpoint = "/food/place/place/";
    const anotheranotherendpoint = "/customer/delete/list";
    const [value, setValue] = useState([]);
    const [value1, setValue1] = useState([]);
    const load = () => {
        fetch(endpoint + prop.display.id, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(fetchResult => {
                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                } else {
                    let list = [];
                    let list2 = [];
                    let counter = 0;
                    for (let i = 0; i < fetchResult[0].food.length; i++) {
                        if ("api" == fetchResult[0].food[i].provider) {
                            fetch(fetchResult[0].food[i].food_id)
                                .then(response2 => response2.json())
                                .then(fetchResult2 => {
                                    if (typeof fetchResult2 === "string" && "invalid token" == fetchResult2) {

                                    } else {
                                        list2.push({ id: fetchResult[0].food[i].food_id, result: fetchResult2 });
                                        if (fetchResult[0].food.length - 1 != counter) {
        
                                        } else {
                                            setValue(list);
                                            setValue1(list2);
                                        }
                                        counter++;
                                    }
                                    
                                })
                        } else {
                            fetch(anotherendpoint + fetchResult[0].food[i].food_id, {
                                method: "GET",
                                headers: {
                                    'Content-Type': 'application/json',
                                    'x-access-token': window.sessionStorage.getItem("token")
                                }
                            })
                                .then(response2 => response2.json())
                                .then(fetchResult2 => {
                                    if (typeof fetchResult2 === "string" && "invalid token" == fetchResult2) {

                                    } else {
                                        list.push(fetchResult2[0]);
                                    if (fetchResult[0].food.length - 1 != counter) {
    
                                    } else {
                                        setValue(list);
                                        setValue1(list2);
                                    }
                                    counter++;
                                    }
                                    
                                })
                        }
                    }
                }
                
            })
    }
    const del_element = (foodid, provider) => {
        fetch(anotheranotherendpoint, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({
                id: prop.display.id, food: {
                    food_id: foodid, provider: provider
                }
            })

        })
            .then(response => response.json())
            .then(fetchResult => {
                






                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                } else {
                    // prop.addId({id: prop.display.id});
                // history.push('/display');
                }
                // prop.addId({id: prop.display.id});
                // history.push('/display');

            });
    }
    /*
    return <div>
        <div className="row">{value.map((placesPlaces) => {
            fetch(anotherendpoint+placesPlaces)
            .then(response=>response.json())
            .then(fetchResult=>{
                return <div className="col"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src={fetchResult[0].image} alt="Card image cap" /><div className="card-body"><h5 className="card-title">{fetchResult[0].name}</h5><p className="card-text">{fetchResult[0].description}</p><button className="btn btn-primary" onClick={() => { window.sessionStorage.setItem("foodId", fetchResult[0].id); prop.addId({ id: prop.display.id }); history.push("/foodAdded"); }}>place</button></div></div></div>;
            })
    })}</div>

        <div className="row">{value1.map((placesPlaces) => {
            fetch(placesPlaces)
            .then(response=>response.json())
            .then(fetchResult=>{
                return <div className="col"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src={fetchResult.recipe.image} alt="Card image cap" /><div className="card-body"><h5 className="card-title">{fetchResult.recipe.label}</h5><button className="btn btn-primary" onClick={() => { window.sessionStorage.setItem("recipe_id", placesPlaces._links.self.href); prop.addId({ id: prop.display.id }); history.push("/displayData"); }}>place</button></div></div></div>;
            })
    })}</div>
    </div>;
    */
    useEffect(load, []);
    return <div>
        <div className="row">{value.map((placesPlaces) => {
            return <div className="col-4"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src={placesPlaces.image} alt="Card image cap" /><div className="card-body"><h5 className="card-title">{placesPlaces.name}</h5><p className="card-text">{placesPlaces.description}</p>
                <button className="btn btn-primary" onClick={() => { window.sessionStorage.setItem("foodId", placesPlaces.id); prop.addId({ id: prop.display.id }); history.push("/foodAdded"); }}>Go to page</button>
                <div style={{marginTop: "10px"}}><form><button className="btn btn-primary" onClick={() => {
                    del_element(placesPlaces.id, 'customer'); prop.addId({ id: prop.display.id });
                    history.push('/display');
                }}>Delete</button></form></div></div></div></div>;
        })}</div>

        <div className="row">{value1.map((placesPlaces) => {
            return <div className="col-4"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src={placesPlaces.result.recipe.image} alt="Card image cap" /><div className="card-body"><h5 className="card-title">{placesPlaces.result.recipe.label}</h5><button className="btn btn-primary" onClick={() => { window.sessionStorage.setItem("recipe_id", placesPlaces.id); prop.addId({ id: prop.display.id }); history.push("/displayData"); }}>Go to page</button><div style={{marginTop: "10px"}}><form><button className="btn btn-primary" onClick={() => {
                del_element(placesPlaces.id, 'api'); prop.addId({ id: prop.display.id });
                history.push('/display');
            }}>Delete</button></form></div></div></div></div>;
        })}</div>
    </div>;
}
function GetData(prop) {
    let history = useHistory();
    const [data, setData] = useState({});
    let default_data = [];
    let default_nutrient = [];
    var endPointfifth = "/comments/place";
    var endPointforth = "/customer/place/place" + "/" + prop.customer.id;
    var endPointthird = "/comments/all" + "/" + prop.display.id.split("/")[6].split("?")[0];
    const [value1, setValue1] = useState([]);
    const [input, setInput] = useState("");
    const endPoint = prop.display.id
    const endPointsecond = "/customer/add/list";
    const load = () => {
        if (undefined === prop.display.noDisplay) {
            fetch(endPoint)
                .then(response => response.json())
                .then(fetchResult => {
                    if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                    } else {
                        console.log("fetch",fetchResult);
                        setData(fetchResult.recipe);
                    }
                    
                });
        } else {
            history.push("/display");
        }
        /*
        console.log(linkReturn)
        console.log("finalData: ", recipeDataReturn)
        setRecipeDataReturn(recipeData)
/*
    link.map((data=>{
        fetched(data)
            .then(response=>response.json())
            .then(fetchResult=>{
                console.log("name", fetchResult)
            })
    }))*/
    }
    if (Object.keys(data).length != 0) {
        default_data = data.ingredients;
        default_nutrient = data.totalNutrients;
    }
    console.log("data", data.length)

    const addlist = () => {
        if (undefined === prop.customer.noDisplay) {
            fetch(endPointsecond, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    'x-access-token': window.sessionStorage.getItem("token")
                },
                body: JSON.stringify({ id: prop.customer.id, food: { food_id: prop.display.id, provider: "api" } })
            }).then(response => response.json())
                .then(fetchResult => { 
                    if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                    } else {

                    }
                })
        }
        else {
            history.push("/place");
        }
    }
    const loading = () => {
        fetch(endPointthird, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    console.log("test",data)
                let list = [];
                list = data;
                let count2 = 0;
                for (let i = 0; i < data.length; i++) {
                    fetch(endPointforth, {
                        method: "GET",
                        headers: {
                            'Content-Type': 'application/json',
                            'x-access-token': window.sessionStorage.getItem("token")
                        }
                    })
                        .then(rep => rep.json())
                        .then(data1 => {
                            if (typeof data1 === "string" && "invalid token" == data1) {

                            } else {
                                list[i]["customer"] = data1[0]
                                if (count2 != (data.length - 1)) {
    
                                } else {
                                    setValue1(list)
                                }
                                count2 = count2 + 1;
                            }
                            
                        })
                }
                }
                
            })
    }
    const loadLoad = () => {
        fetch(endPointfifth, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({ customerId: prop.customer.id, foodId: prop.display.id.split("/")[6].split("?")[0], text: input, date: new Date() })
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({id: prop.customer.id});
                    history.push("/displayData");
                }
                
            })

    }
    const loadloadload = () => {
        load();
        loading();
    }
    console.log("id",prop.display.id.split("/")[6].split("?")[0]);
    useEffect(loadloadload, [])

    return (<div>
        <div className="container-fluid" style={{ padding: "16px", minWidth: "1000px", width: "calc(100% - 190px * 2)", margin: "0 auto" }}>

            <div className="page-wrapper ">
                <div className="container recipe-detail-container ">
                    <div className="rm ">
                        <div className="recipe-main-photo"><img className="recipe-cover-photo" src={data.image} />
                        </div>
                        <div className="recipe-detail-content">


                            <h3 className="recipe-name">{data.label}</h3>



                            <div className="button-recipe"><span>346 Saves</span><button className="btn btn-link" onClick={addlist}><img className="icon-like" /></button></div>




                            <div className="recipe-stats-info"><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="1" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="2" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="3" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="4" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="5" />
                                <span>9</span>
                                <div className="total-likes">
                                    <img src="https://www.cooky.vn/React/images/icons/heart.svg" /><span>346</span>
                                </div>

                                <div>
                                    <img src="https://www.cooky.vn/React/images/icons/view.svg" /><span>11k</span>
                                </div>

                            </div>



                            <div className="recipe-owner"><a href={data.url}>
                                <div className="recipe-owner-avatar"><img src="https://image.cooky.vn/usr/g10/96128/avt/s140/cooky-avatar-636959526416611860.jpg" />
                                </div>
                                <div className="recipe-owner-name">
                                    <h4><a href={data.url}>{data.source}</a></h4>
                                </div>
                            </a>
                                <div className="make-recipe-button"><img src="https://www.cooky.vn/React/images/icons/i-made-it-desktop.svg" /><span>I
                                    made it</span></div>
                            </div>

                            <div className="recipe-ingredient">
                                <h3>Ingredients</h3><span>Servings:{data.yield}</span>
                            </div>


                            <div id="ingredients-list">
                                {default_data.map((ingre) => {
                                    return <div className="ingredient-item"><span className="ingredient-name">{ingre.text}</span><span className="ingredient-quantity">{parseInt(ingre.weight)} Grams</span></div>;
                                })}
                            </div>



                            <div className="recipe-ads-banner-container">
                                <div className="banner-wrapper">
                                    <div className="banner animated-place-holder"></div>
                                </div>
                            </div>

                            <div className="recipe-steps-list">
                                <h3>Steps</h3>
                                <button className="btn btn-outline-dark"><a href={data.url} style={{color: "black"}}>Step details</a></button>
                            </div>

                            <div className="recipe-ingredient">
                                <h3>Total Nutrients</h3><span></span>
                            </div>


                            <div id="ingredients-list">
                                {Object.values(default_nutrient).map((nutri) => {
                                    return <div className="ingredient-item"><span className="ingredient-name">{nutri.label}</span><span className="ingredient-quantity">{parseInt(nutri.quantity) + nutri.unit}</span></div>;
                                })}
                            </div>



                            <h3 className="how-to-make">Comment</h3>
                            <div className="recipe-comment-form-action">
                                <div className="user-avatar"><img
                                    src="https://cdn-icons-png.flaticon.com/512/149/149071.png" /></div>
                                <div className="form-content">
                                    <textarea className="recipe-description" placeholder="Comment" spellcheck="false" value={input} onChange={(e) => { setInput(e.target.value) }}></textarea>
                                    <div className="comment-btn-action"><form><button
                                        className="btn-submit-review" onClick={loadLoad}>Upload</button></form></div>
                                </div>
                            </div>
                            <div className="recipe-review">
                                {value1.map((placesPlaces) => {
                                    return <div className="recipe-review-item"><img className="review-owner-avatar" src="https://cdn-icons-png.flaticon.com/512/149/149071.png" />
                                        <div className="review-item-info"><span className="review-owner-name">{placesPlaces["customer"].firstName + " " + placesPlaces["customer"].lastName}</span><span className="review-created-day">{placesPlaces.date}</span>
                                            <div className="review-desc">{placesPlaces.text}</div>
                                        </div>
                                    </div>;
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>);
}
function getIndex(array, value) {
    var result = 0;
    if (0 != array.length) {
        for (let i = 0; i < array.length; ++i) {
            if (value == array[i].dietName) {
                result = i;
            }
        }
    } else {
        result = -1;
    }
    return result;
}
function Display({ addId }) {
    let history = useHistory();
    var endPoint = "/customer/placePlaceplace";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ customerName: "", customerPassword: "" });
    }
    const load = () => {
        fetch(endPoint + "/" + value.customerName + "/" + value.customerPassword)
            .then(response => response.json())
            .then(data => {
                if (undefined === data[0].invalid) {
                    window.sessionStorage.setItem("token", data[0].token);
                    window.sessionStorage.setItem("id", data[0].id);
                    addId({ id: data[0].id });
                } else {
                    console.log(data[0].invalid);
                }
            });
    };
    const placesPlacesplaces = () => {
        if (null === window.sessionStorage.getItem("id")) {
        } else {
            history.push("/display");
        }
    };
    useEffect(
        placesPlacesplaces
    );
    var places = <button type="submit" value="" className="button form-control" style={{ backgroundImage: "linear-gradient(-90deg, #f54f7c 0%, #f3413b 100%)", color: "white", marginBottom: "40px" }} onClick={(e) => { e.preventDefault(); load() }}>LOG IN</button>;
    return <div style={{ marginBottom: "10px", padding: "0px 25px" }}><input type="text" name="customer-name" id="customer-name" className="form-control button" value={value.customerName} onChange={(e) => { setValue({ customerName: e.target.value, customerPassword: value.customerPassword }) }} placeholder="Email" style={{ marginBottom: "20px" }} /><input type="password" name="customer-password" id="customer-password" className="form-control button" value={value.customerPassword} onChange={(e) => { setValue({ customerName: value.customerName, customerPassword: e.target.value }) }} placeholder="Password" />{places}</div>;
}
function Register() {
    let history = useHistory();
    var endPoint = "/customer/place";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ customerName: "", customerPassword: "", customerCustomerPassword: "" });
    }
    const load = () => {
        if (value.customerCustomerPassword != value.customerPassword) {
        } else {
            if (value.customerName == "" || value.customerPassword == "" || value.customerCustomerPassword == "") {
            } else {
                fetch(endPoint, {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ customerName: value.customerName, customerPassword: value.customerPassword })
                }).then(response => response.json())
                    .then(data => {
                        console.log(data);
                        if (undefined === data[0].invalid) {
                            history.push("/place");
                        } else {
                            console.log(data[0].invalid);
                        }
                    });
            }
        }
    };
    var places = <button type="submit" value="" className="button form-control" style={{ backgroundImage: "linear-gradient(-90deg, #f54f7c 0%, #f3413b 100%)", color: "white", marginBottom: "40px" }} onClick={(e) => { e.preventDefault(); load() }}>Register</button>;
    return <div style={{ marginBottom: "10px", padding: "0px 25px" }}><input type="text" name="customer-name" id="customer-name" className="form-control button" value={value.customerName} onChange={(e) => { setValue({ customerName: e.target.value, customerPassword: value.customerPassword, customerCustomerPassword: value.customerCustomerPassword }) }} placeholder="Email" style={{ marginBottom: "20px" }} /><input type="password" name="customer-password" id="customer-password" className="form-control button" value={value.customerPassword} onChange={(e) => { setValue({ customerName: value.customerName, customerPassword: e.target.value, customerCustomerPassword: value.customerCustomerPassword }) }} placeholder="Password" style={{ marginBottom: "20px" }} /><input type="password" name="customer-customer-password" id="customer-customer-password" className="form-control button" value={value.customerCustomerPassword} onChange={(e) => { setValue({ customerName: value.customerName, customerPassword: value.customerPassword, customerCustomerPassword: e.target.value }) }} placeholder="Password" />{places}</div>;
}
function ResetPassword() {
    let history = useHistory();
    var endPoint = "/customers/reset/email";
    const [value, setValue] = useState("");
    const load = () => {
        
        fetch(endPoint, {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ customerName: value})
        }).then(response => response.json())
            .then(data => {
                console.log(data);
                if (undefined === data[0].invalid) {
                    history.push("/place/verify");
                } else {
                    console.log(data[0].invalid);
                }
            });
    };
    var places = <button type="submit" value="" className="button form-control" style={{ backgroundImage: "linear-gradient(-90deg, #f54f7c 0%, #f3413b 100%)", color: "white", marginBottom: "40px" }} onClick={(e) => { e.preventDefault(); load() }}>RECOVER</button>;
    return <div style={{ marginBottom: "10px", padding: "0px 25px" }}><input type="text" name="customer-name" id="customer-name" className="form-control button" value={value} onChange={(e) => { setValue(e.target.value) }} placeholder="Email" style={{ marginBottom: "20px" }} />{places}</div>;
}


function ResetPassword2() {
    let history = useHistory();
    var endPoint = "/customers/verify/code";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ customerName: "", customerPassword: "",customerCustomerPassword: "",verificationCode: 0 });
    }
    const load = () => {
        if(value.customerPassword != value.customerCustomerPassword){

        }else{
            if(value.customerName == "" || value.customerPassword == "" || value.customerCustomerPassword == "" || value.verificationCode == 0){

            } else {
                fetch(endPoint, {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ customerName: value.customerName,customerPassword: value.customerPassword,verificationCode: parseInt(value.verificationCode)})
                }).then(response => response.json())
                    .then(data => {
                        console.log(data);
                        if (undefined === data[0].invalid) {
                            history.push("/place");
                        } else {
                            console.log(data[0].invalid);
                        }
                    });
            }
        }
        
    };
    var places = <button type="submit" value="" className="button form-control" style={{ backgroundImage: "linear-gradient(-90deg, #f54f7c 0%, #f3413b 100%)", color: "white", marginBottom: "40px" }} onClick={(e) => { e.preventDefault(); load() }}>RECOVER</button>;
    return <div style={{ marginBottom: "10px", padding: "0px 25px" }}><input type="text" name="verificationCode" id="verificationCode" className="form-control button" value={value.verificationCode} onChange={(e) => { setValue({ customerName: value.customerName, customerPassword: value.customerPassword,customerCustomerPassword: value.customerCustomerPassword,verificationCode: e.target.value }) }} placeholder="Verify Code" style={{ marginBottom: "20px" }} /><input type="text" name="customer-name" id="customer-name" className="form-control button" value={value.customerName} onChange={(e) => { setValue({customerName: e.target.value, customerPassword: value.customerPassword,customerCustomerPassword: value.customerCustomerPassword,verificationCode: value.verificationCode})}} placeholder="Email" style={{ marginBottom: "20px" }} /><input type="password" name="customer-password" id="customer-password" className="form-control button" value={value.customerPassword} onChange={(e) => { setValue({customerName: value.customerName, customerPassword: e.target.value,customerCustomerPassword: value.customerCustomerPassword,verificationCode: value.verificationCode})}} placeholder="Password" style={{ marginBottom: "20px" }} /><input type="password" name="customer-customer-password" id="customer-customer-password" className="form-control button" value={value.customerCustomerPassword} onChange={(e) => { setValue({customerName: value.customerName, customerPassword: value.customerPassword,customerCustomerPassword: e.target.value,verificationCode: value.verificationCode})}} placeholder="Password" />{places}</div>;
}


function DisplayAndRegister({ addAddaddId }) {
    let { path, url } = useRouteMatch();
    return (
        <div className="container" style={{ paddingLeft: "300px", paddingRight: "300px" }}>
            <form className="datdaidi button">
                <div className="text-center" style={{ marginBottom: "20px", borderBottom: "solid", padding: "25px 0px", borderWidth: "thin" }}>
                    <div className="col " style={{ fontWeight: "bold", color: "#333333", display: "inline", marginRight: "50px" }}><a href={`${url}`}>Sign In</a></div>
                    <div className="col " style={{ fontWeight: "bold", color: "#333333", display: "inline", marginLeft: "50px" }}><a href={`${url}/register`}>Sign Up</a></div>
                    
                </div>
                <div className="form-group">
                    <button className="form-control"
                        style={{ backgroundColor: "#dd4b39", color: "#F3F3F3", textAlign: "start" }}><i
                            className="fa fa-google fa-fw" style={{ marginRight: "10px" }}>
                        </i>Sign in with
                        Google</button>
                    <div className="col " ><a href={`${url}/reset`}>Forgot Password?</a></div>

                </div>
                <Switch>
                    <Route exact path={path}>
                        <Display addId={(id) => { addAddaddId(id) }} />
                    </Route>
                    <Route path={`${path}/register`}>
                        <Register />
                    </Route>
                    <Route path={`${path}/reset`}>
                        <ResetPassword />
                    </Route>
                    <Route path={`${path}/verify`}>
                        <ResetPassword2 />
                    </Route>
                </Switch>

            </form>
        </div>
    );
}
function DisplayPage() {
    const [recipeDataReturn, setRecipeDataReturn] = useState([]);
    const [userecipeDataReturn, setUserRecipeDataReturn] = useState([]);
    const [userFoodReturn, setUserFoodReturn] = useState([]);
    let fetched = []
    let endPoint = "https://api.edamam.com/api/recipes/v2/?q=dessert&type=public&app_id=fe1da2d2&app_key=%2006a4dadc3c947a1b4b7a0e15622cb4fe&random=true"
    let endPoint2 = "/food/all/place";
    const display1=()=>{
    fetch(endPoint)
    .then(response=>response.json())
    .then(fetchResult=>{
        fetched = fetchResult.hits;
        console.log("f",fetchResult);
        fetch(endPoint2)
        .then(response2=>response2.json())
        .then(data=>{
            setUserFoodReturn(data)
            setRecipeDataReturn(fetched)
        })
    })
    }
    useEffect(display1,[])
    /*
                     <div className="row">
                        {recipeDataReturn.map((data) => {
                            return <div className="col">
                                <div className="card" style={{ width: "12rem", border: "none", borderRadius: "2px" }}>
                                    <img className="card-img-top" src={data.recipe.image} alt="Card image cap" style={{ borderRadius: "5px" }} />
                                    <div className="card-body">
                                        <a href="/displayData" className="card-title" style={{ color: "black" }} onClick={() => {
                                            window.sessionStorage.setItem("recipe_id", data._links.self.href)
                                        }}>{data.recipe.label}</a>
                                    </div>
                                </div>
                            </div>;
                        })}
                    </div>
    */
    return <section style={{paddingLeft: "500px",paddingRight: "400px", paddingTop: "10px", paddingBottom: "10px;"}}>
  <div id="carouselExampleIndicators" className="carousel slide" data-ride="carousel" style={{marginBottom: "20px"}}>
    <ol className="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" className="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div className="carousel-inner" style={{borderRadius: "15px"}}>
      <div className="carousel-item active">
        <img className="d-block w-100" src="https://media.cooky.vn/ads/s/cooky-ads-637647023121328984.jpg" alt="First slide"/>
      </div>
      <div className="carousel-item">
        <img className="d-block w-100" src="https://media.cooky.vn/ads/s/cooky-ads-637647024813184219.jpg" alt="Second slide"/>
      </div>
      <div className="carousel-item">
        <img className="d-block w-100" src="https://media.cooky.vn/ads/s/cooky-ads-637647022853830603.jpg" alt="Third slide"/>
      </div>
    </div>
    <a className="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span className="carousel-control-prev-icon" aria-hidden="true"></span>
      <span className="sr-only">Previous</span>
    </a>
    <a className="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span className="carousel-control-next-icon" aria-hidden="true"></span>
      <span className="sr-only">Next</span>
    </a>
  </div>
  <div className="container-fluid">
    <div className="home-top-box" style={{marginBottom: "20px"}}>
      <div className="headline" style={{borderBottom: "#000054 solid"}}>
        <h2>Recipe by web</h2>
      </div>
      <div className="row">
                        {recipeDataReturn.map((data) => {
                            return <div className="col">
                                <div className="card" style={{ width: "12rem", border: "none", borderRadius: "2px" }}>
                                    <img className="card-img-top" src={data.recipe.image} alt="Card image cap" style={{ borderRadius: "5px" }} />
                                    <div className="card-body">
                                        <a href="/displayData" className="card-title" style={{ color: "black" }} onClick={() => {
                                            window.sessionStorage.setItem("recipe_id", data._links.self.href)
                                        }}>{data.recipe.label}</a>
                                    </div>
                                </div>
                            </div>;
                        })}
                    </div>
    </div>
  </div>
  
  <div className="container-fluid">
    <div className="home-top-box" style={{marginBottom: "20px"}}>
      <div className="headline" style={{borderBottom: "#000054 solid"}}>
        <h2>Recipe by users</h2>
      </div>
    </div>
    <div className="row">
      { userFoodReturn.map((data) => {
                            return <div className="col">
                                <div className="card" style={{ width: "12rem", border: "none", borderRadius: "2px" }}>
                                    <img className="card-img-top" src={data.image} alt="Card image cap" style={{ borderRadius: "5px" }} />
                                    <div className="card-body">
                                        <a href="/foodAdded" className="card-title" style={{ color: "black" }} onClick={() => {
                                            window.sessionStorage.setItem("foodId", data.id)
                                        }}>{data.name}</a>
                                    </div>
                                </div>
                            </div>;
                        })}
    </div>
  </div>
</section>
    ;
}
function DisplayFoodAdded(prop) {
    let history = useHistory();
    var endPointfifth = "/comments/place";
    var endPointforth = "/customer/place/place" + "/" + prop.customer.id;
    var endPointthird = "/comments/all" + "/" + prop.display.id;
    var endPoint = "/food/place/place";
    const [value, setValue] = useState({ name: "", description: "", ingredients: [], diet: [], steps: [] });
    const [value1, setValue1] = useState([]);
    const [input, setInput] = useState("");
    const endPointsecond = "/customer/add/list";
    const load = () => {
        if (undefined === prop.display.noDisplay) {
            fetch(endPoint + "/" + prop.display.id, {
                method: "GET",
                headers: {
                    'Content-Type': 'application/json',
                    'x-access-token': window.sessionStorage.getItem("token")
                }
            })
                .then(response => response.json())
                .then(data => {
                    if (typeof data === "string" && "invalid token" == data) {

                    } else {
                        setValue(data[0]);
                    }
                    
                });
        } else {
            history.push("/display");
        }
    };
    const addlist = () => {
        if (undefined === prop.customer.noDisplay) {
            fetch(endPointsecond, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    'x-access-token': window.sessionStorage.getItem("token")
                },
                body: JSON.stringify({ id: prop.customer.id, food: { food_id: prop.display.id, provider: "customer" } })
            }).then(response => response.json())
                .then(fetchResult => { 
                    if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                    } else {
                        
                    }
                })
        }
        else {
            history.push("/place");
        }
    };
    const loading = () => {
        fetch(endPointthird, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    let list = [];
                    list = data;
                    let count2 = 0;
                    for (let i = 0; i < data.length; i++) {
                        fetch(endPointforth, {
                            method: "GET",
                            headers: {
                                'Content-Type': 'application/json',
                                'x-access-token': window.sessionStorage.getItem("token")
                            }
                        })
                            .then(rep => rep.json())
                            .then(data1 => {
                                if (typeof data1 === "string" && "invalid token" == data1) {

                                } else {
                                    list[i]["customer"] = data1[0]
                                    if (count2 != (data.length - 1)) {
        
                                    } else {
                                        setValue1(list)
                                    }
                                    count2 = count2 + 1;
                                }
                                
                            })
                    }
                }
                
            })
    }
    const loadLoad = () => {
        fetch(endPointfifth, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({ customerId: prop.customer.id, foodId: prop.display.id, text: input, date: new Date() })
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({ id: prop.customer.id })
                    history.push("/foodAdded");
                }
                
            })

    }
    const loadloadload = () => {
        load();
        loading();
    }
    useEffect(
        loadloadload
        , []);
    return (
        <div className="container-fluid" style={{ padding: "16px", minWidth: "1000px", width: "calc(100% - 190px * 2)", margin: "0 auto" }}>

            <div className="page-wrapper ">
                <div className="container recipe-detail-container ">
                    <div className="rm ">
                        <div className="recipe-main-photo"><img className="recipe-cover-photo" src={value.image} />
                        </div>
                        <div className="recipe-detail-content">


                            <h3 className="recipe-name">{value.name}</h3>



                            <div className="button-recipe"><span>346 Saves</span><button className="btn btn-link" onClick={addlist}><img className="icon-like" /></button></div>




                            <div className="recipe-stats-info"><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="1" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="2" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="3" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="4" /><img className="star-icon" src="https://www.cooky.vn/React/images/icons/star.svg" alt="5" />
                                <span>9</span>
                                <div className="total-likes">
                                    <img src="https://www.cooky.vn/React/images/icons/heart.svg" /><span>346</span>
                                </div>

                                <div>
                                    <img src="https://www.cooky.vn/React/images/icons/view.svg" /><span>11k</span>
                                </div>

                            </div>



                            <div className="recipe-owner"><a>
                                <div className="recipe-owner-avatar"><img src="https://image.cooky.vn/usr/g10/96128/avt/s140/cooky-avatar-636959526416611860.jpg" />
                                </div>
                                <div className="recipe-owner-name">
                                    <span></span>
                                </div>
                            </a>
                                <div className="make-recipe-button"><img src="https://www.cooky.vn/React/images/icons/i-made-it-desktop.svg" /><span>I
                                    made it</span></div>
                            </div>



                            <div className="recipe-desc-less">
                                <p>{value.description}</p>
                            </div>
                            <div id="ingredients-list">
                                {value.ingredients.map((placePlaces) => {
                                    return <div className="ingredient-item"><span className="ingredient-name">{placePlaces.ingredientName}</span><span className="ingredient-quantity">{placePlaces.ingredientNum+placePlaces.ingredientLast}</span></div>;
                                 })}

                            </div>



                            <div className="recipe-ads-banner-container">
                                <div className="banner-wrapper">
                                    <div className="banner animated-place-holder"></div>
                                </div>
                            </div>

                            <div className="recipe-steps-list">
                                <h3 className="how-to-make">Steps</h3>
                                <div className="cook-step-content">
                                    {value.steps.map((placePlaces)=>{
                                        return <div className="cook-step-item">
                                        <div className="step-number">{placePlaces.stepNum}</div>
                                        <div className="step-content">
                                            <p>{placePlaces.stepDetail}</p>
                                        </div>
                                    </div> ;
                                    })}
                                </div>
                            </div>

                            <div className="recipe-steps-list">
                                <h3 className="how-to-make">Diet</h3>
                                <div className="cook-step-content">
                                    {value.diet.map((placePlaces)=>{
                                        return <div className="cook-step-item">
                                        <div className="step-content">
                                            <p>{placePlaces.dietName}</p>
                                        </div>
                                    </div> ;
                                    })}
                                </div>
                            </div>



                            <h3 className="how-to-make">Comments</h3>
                            <div className="recipe-comment-form-action">
                                <div className="user-avatar"><img
                                    src="https://cdn-icons-png.flaticon.com/512/149/149071.png" /></div>
                                <div className="form-content">
                                    <textarea className="recipe-description" placeholder="Comment" spellcheck="false" value={input} onChange={(e) => { setInput(e.target.value) }}></textarea>
                                    <div className="comment-btn-action"><form><button
                                        className="btn-submit-review" onClick={loadLoad}>Upload</button></form></div>
                                </div>
                            </div>
                            <div className="recipe-review">
                                {value1.map((placesPlaces) => {
                                    return <div className="recipe-review-item"><img className="review-owner-avatar" src="https://cdn-icons-png.flaticon.com/512/149/149071.png" />
                                        <div className="review-item-info"><span className="review-owner-name">{placesPlaces["customer"].firstName + " " + placesPlaces["customer"].lastName}</span><span className="review-created-day">{placesPlaces.date}</span>
                                            <div className="review-desc">{placesPlaces.text}</div>
                                        </div>
                                    </div>;
                                })}
                            </div>
                        </div>

                    </div>
                    </div>
            </div>
        </div>
    );
}
function DisplayCustomerFoodAdded(prop) {
    let history = useHistory();
    var endPoint = "/food/place/food";
    let endPoint2 = "/food/"
    const [value, setValue] = useState([]);
    const load = () => {
        fetch(endPoint + '/' + prop.display.id, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    setValue(data);
                }
                
            });
    };
    const deleteFood = (foodId) => {
        fetch(endPoint2 + foodId, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(fetchResult => {
                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                } else {
                    prop.addId({id: prop.display.id});
                    history.push("/display");
                }
                
            })
    }
    /*
const deleteFood=(foodId)=>{
    fetch(endPoint2+foodId,{
        method:"DELETE",
        headers:{
            "Content-Type": "application/json"
        }
    })
    .then(response=>response.json())
    .then(fetchResult=>{
        prop.addId({id: prop.display.id})
        history.push("/display")
    })
}
*/
    useEffect(
        load
        , []);
    return <div className="row">{value.map((placesPlaces) => {
        return <div className="col-4"><div className="card" style={{ width: "18rem;" }}><img className="card-img-top" src={placesPlaces.image} alt="Card image cap" /><div className="card-body"><h5 className="card-title">{placesPlaces.name}</h5><p className="card-text">{placesPlaces.description}</p><button className="btn btn-primary" style={{marginRight: "10px"}} onClick={() => { window.sessionStorage.setItem("foodId", placesPlaces.id); prop.addId({ id: prop.display.id }); history.push("/foodAdded"); }}>View</button><button className="btn btn-info" style={{marginRight: "10px"}} onClick={() => { window.sessionStorage.setItem("foodId", placesPlaces.id); prop.addId({ id: prop.display.id }); history.push("/customerFoodUpdate"); }}>Edit</button><button className="btn btn-info" onClick={() => { deleteFood(placesPlaces.id) }}>Delete</button></div>
            </div></div>;
    })}</div>;
}
function DisplayCustomer(prop) {
    let { path, url } = useRouteMatch();
    let history = useHistory();
    var endPoint = "/customer/place/place";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ id: "", lastName: "", firstName: "", address: "", place: [] });
    }
    const load = () => {
        if (undefined === prop.display.noDisplay) {
            fetch(endPoint + "/" + prop.display.id, {
                method: "GET",
                headers: {
                    'Content-Type': 'application/json',
                    'x-access-token': window.sessionStorage.getItem("token")
                }
            })
                .then(response => response.json())
                .then(data => {
                    if (typeof data === "string" && "invalid token" == data) {

                    } else {
                        setValue(data[0]);
                    }
                    
                });
        } else {
            history.push("/place");
        }
    };
    const placesPlacesplaces = () => {
        prop.addId({ id: prop.display.id });
        history.push("/customerUpdate");
    };
    const customerFoodAdded = () => {
        prop.addId({ id: prop.display.id });
        history.push(`${url}/customerFoodAdded`);
    };
    const customerFoodDisplay = () => {
        prop.addId({ id: prop.display.id });
        history.push(`${url}/customerFoodDisplay`);
    };
    useEffect(
        load
        , []);
    return (
        <div className="container">
            <div className="row">
                <div className="col">
                    <div>
                        <img src="" alt="" />
                    </div>
                </div>
                <div className="col">
                    <div className="container">
                        <div className="row">
                            <div className="col">
                                Last name
                            </div>
                            <div className="col">
                                {value.lastName}
                            </div>
                        </div>
                        <div className="row">
                            <div className="col">
                                First name
                            </div>
                            <div className="col">
                                {value.firstName}
                            </div>
                        </div>
                        <div className="row">
                            <div className="col">
                                Address
                            </div>
                            <div className="col">
                                {value.address}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col" style={{ border: "none", padding: "0px" }}>
                    <div className="form-group">
                        <button className="form-control" style={{ border: "none", textDecoration: "none", borderBottom: "#111111 solid", borderRadius: "0px" }} onClick={placesPlacesplaces}>Edit Info</button>
                    </div>
                </div>
                <div className="col-0" style={{ width: "0px", padding: "0px" }}>
                </div>
            </div>
            <div className="row">
                <div className="col" style={{ border: "none", padding: "0px" }}>
                    <div className="form-group">
                        <button className="form-control" onClick={customerFoodAdded}>Created Recipe</button>
                    </div>
                </div>
                <div className="col" style={{ border: "none", padding: "0px" }}>
                    <div className="form-group">
                        <button className="form-control" onClick={customerFoodDisplay}>Added Recipe</button>
                    </div>
                </div>
            </div>
            <Route path={`${path}/customerFoodAdded`}>
                <DisplayCustomerFoodAdded display={prop.display} addId={(id) => { prop.addId(id) }} />
            </Route>
            <Route path={`${path}/customerFoodDisplay`}>
                <DisplayCustomerFoodChoice display={prop.display} addId={(id) => { prop.addId(id) }} />
            </Route>
        </div>
    );
}
function DisplayCustomerUpdate(prop) {
    let history = useHistory();
    var endPoint = "/customer/place/place";
    var endPointendPoint = "/customer/place/place/place";
    const [value, setValue] = useState({});
    if (0 != Object.keys(value).length) {
    } else {
        setValue({ id: "", lastName: "", firstName: "", address: "" });
    }
    const load = () => {
        if (undefined === prop.display.noDisplay) {
            fetch(endPoint + "/" + prop.display.id, {
                method: "GET",
                headers: {
                    'Content-Type': 'application/json',
                    'x-access-token': window.sessionStorage.getItem("token")
                }
            })
                .then(response => response.json())
                .then(data => {
                    if (typeof data === "string" && "invalid token" == data) {

                    } else {
                        setValue({ id: data[0].id, lastName: data[0].lastName, firstName: data[0].firstName, address: data[0].address });
                    }
                });
        } else {
            history.push("/place");
        }
    };
    const placesPlacesplaces = () => {
        fetch(endPointendPoint, {
            method: "PUT",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify(value)
        }).then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({ id: prop.display.id });
                    history.push("/display");
                }
                
            });
    };
    useEffect(
        load
        , []);
    return <div className="container"><div className="row"><div className="col">Last name</div><div className="col"><div className="form-group"><input type="text" id="lastName" name="lastName" className="form-control" value={value.lastName} onChange={(e) => { setValue({ id: value.id, lastName: e.target.value, firstName: value.firstName, address: value.address }) }} /></div></div></div><div className="row"><div className="col">First name</div><div className="col"><div className="form-group"><input type="text" id="firstName" name="firstName" className="form-control" value={value.firstName} onChange={(e) => { setValue({ id: value.id, lastName: value.lastName, firstName: e.target.value, address: value.address }) }} /></div></div></div><div className="row"><div className="col">Address</div><div className="col"><div className="form-group"><input type="text" id="address" name="address" className="form-control" value={value.address} onChange={(e) => { setValue({ id: value.id, lastName: value.lastName, firstName: value.firstName, address: e.target.value }) }} /></div></div></div><div className="row"><div className="form-group"><button className="form-control" onClick={placesPlacesplaces}>Submit</button></div></div></div>;
}
function DisplayPlaces(prop) {
    const load = () => {
        if (null === window.sessionStorage.getItem("id")) {
            prop.deleteId({ noDisplay: "No Display" });
        } else {
            window.sessionStorage.removeItem("id");
            prop.deleteId({ noDisplay: "No Display" });
        }
    };
    var places = <div></div>;
    if (undefined === prop.display.noDisplay) {
        places = <div className="dropdown" style={{ display: "inline-block", marginLeft: "10px" }}><button className="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">User</button><div className="dropdown-menu" aria-labelledby="dropdownMenu2"><a className="dropdown-item" href="/customerPlace">Customer's Page</a><a className="dropdown-item" href="/customerFood">Create Recipe</a><a className="dropdown-item" href="/place" onClick={load}>Log Out</a></div></div>;
    } else {
        places = <a className="btn btn-outline-light" style={{ marginLeft: "10px" }} href="/place" onClick={load}>Log In</a>;
    }
    return <div>{places}</div>;
}
/** 
  <!-- <div class="dropdown d-inline-flex p-2">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              Dropdown button
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
              <div>
                <a class="dropdown-item" href="#">Action</a>
              </div>
              <div>
                <a class="dropdown-item" href="#">Another action</a>
              </div>
              <div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </div>
          </div> -->
    <button className="btn btn-outline-light " style={{marginLeft: "10px"}}>113</button>
              <button className="btn btn-outline-light " style={{marginLeft: "10px"}}>Dang Nhap</button>
 **/
function List(prop) {
    const [recipeDataReturn, setRecipeDataReturn] = useState([])
    const [termReturn, setTermReturn] = useState("")
    const [nextEndPointReturn, setNextEndPointReturn] = useState("")
    const [userRecipeReturn, setUserRecipeReturn] = useState([])
    const [cal, setCal] = useState({ from: "", to: "" });
    const [diet, setDiet] = useState([]);
    const [health, setHealth] = useState([]);
    let recipeData = []
    let fetched = []
    let nEndP = ""
    let calories = ""
    let diets = ""
    let healths = ""
    if (cal.from != "" && cal.to == "") {
        calories = "&calories=" + cal.from + "+";
    } else if (cal.from != "" && cal.to != "") {
        calories = "&calories=" + cal.from + "-" + cal.to;
    } else if (cal.from == "" && cal.to != "") {
        calories = "&calories=" + cal.to;
    } else {
        calories = "";
    }
    for (let i = 0; i < diet.length; i++) {
        diets = diets + "&diet=" + diet[i];
    }
    console.log(diet)
    console.log(healths)
    const checkbox = (e) => {
        let data = diet;
        if (e.target.checked) {
            data.push(e.target.value);
        } else {
            data.indexOf(e.target.value);
            data.splice(data.indexOf(e.target.value), 1);
        }
        console.log(data)
        setDiet(data)

    }
    for (let i = 0; i < health.length; i++) {
        healths = healths + "&health=" + health[i];
    }
    const checkboxHealth = (e) => {
        let data = health;
        if (e.target.checked) {
            data.push(e.target.value);
        } else {
            data.indexOf(e.target.value);
            data.splice(data.indexOf(e.target.value), 1);
        }
        console.log(data)
        setHealth(data)

    }
    const endPoint = "https://api.edamam.com/api/recipes/v2?type=public&q=" + prop.valueDisplay + "&app_id=fe1da2d2&app_key=%2006a4dadc3c947a1b4b7a0e15622cb4fe" + calories + diets
    const endPoint2 = "/food/search/" + prop.valueDisplay.toLowerCase()
    const load = () => {
        fetch(endPoint)
            .then(response => response.json())
            .then(fetchResult => {
                console.log("test",prop.valueDisplay)
                window.sessionStorage.removeItem("value")
                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {

                } else {
                    fetched = fetchResult.hits;
                    if(0 == fetched.length){
                        setUserRecipeReturn([])
                        setRecipeDataReturn([])
                        setNextEndPointReturn("")
                    }else{
                        nEndP = fetchResult._links.next.href
                        fetch(endPoint2)
                            .then(response2 => response2.json())
                            .then(fetchResult2 => {
                                if (typeof fetchResult2 === "string" && "invalid token" == fetchResult2) {
    
                                } else {
                                    setUserRecipeReturn(fetchResult2)
                                setRecipeDataReturn(fetched)
                                setNextEndPointReturn(nEndP)
                                }
                                
        
                            })
                    }
                   
                }
                
            })
        /*
        console.log(linkReturn)
        console.log("finalData: ", recipeDataReturn)
        setRecipeDataReturn(recipeData)
/*
    link.map((data=>{
        fetched(data)
            .then(response=>response.json())
            .then(fetchResult=>{
                console.log("name", fetchResult)
            })
    }))*/
    }
    const next = () => {
        if(nextEndPointReturn == ""){
            setNextEndPointReturn("");
            setRecipeDataReturn([]);
        }else{
            fetch(nextEndPointReturn)
            .then(response => response.json())
            .then(fetchResult => {
                if (typeof fetchResult === "string" && "invalid token" == fetchResult) {
                    
                } else {
                    nEndP = fetchResult._links.next.href
                setNextEndPointReturn(nEndP)
                let storedNextRecipes = [];
                let storedRecipes = [];
                let concat = [];
                storedNextRecipes = fetchResult.hits;
                console.log("new", storedNextRecipes)
                storedRecipes = recipeDataReturn;
                concat = storedRecipes.concat(storedNextRecipes);
                setRecipeDataReturn(concat)
                }
                
            })
        }
        
    }
    console.log("123: ", recipeDataReturn);
    console.log(recipeDataReturn.length);
    /*useEffect(()=>{load()},[])*/
    useEffect(() => {
        if (null == window.sessionStorage.getItem("value")) {
        } else {
            load();
        }
    })
    return (
        <div>
            <section>
                <div className="nav-item dropdown megamenu"><a id="megamneu" href="" data-toggle="dropdown" aria-haspopup="true"
                    aria-expanded="false" className="nav-link dropdown-toggle font-weight-bold text-uppercase text-center" style={{width:"40%", marginLeft:"200px"}}>Search refine
                    </a>
                    <div aria-labelledby="megamneu" className="dropdown-menu border-0 p-0 m-0">
                        <div className="container">
                            <div className="row bg-white rounded-0 m-0 shadow-sm">
                                <div className="col">
                                    <div className="p-4">
                                        <div className="row">
                                            <div className="col-2">
                                                <h6 className="font-weight-bold text-uppercase">Calories</h6>
                                                <div className="form-group row ">
                                                    <label for="StartingCal" className="col-sm-3 col-form-label">From</label>
                                                    <div className="col-sm-10">
                                                        <input type="text" className="form-control w-50" id="StartingCal" value={cal.from} onChange={(e) => {
                                                            setCal({ from: e.target.value, to: cal.to })
                                                        }} />
                                                    </div>
                                                </div>
                                                <div className="form-group row ">
                                                    <label for="EndCal" className="col-sm-3 col-form-label">To</label>
                                                    <div className="col-sm-10">
                                                        <input type="text" className="form-control w-50" id="EndCal" value={cal.to} onChange={(e) => {
                                                            setCal({ from: cal.from, to: e.target.value })
                                                        }} />
                                                    </div>
                                                </div>
                                                <p style={{ fontWeight: "bold;" }}>Ingredient</p>
                                                <div className="form-group row ">
                                                    <label for="Ingredient" className="col-sm-5 col-form-label">Up to</label>
                                                    <div className="col-sm-10">
                                                        <input type="text" className="form-control w-50" id="Ingredient" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-5">
                                                <h6 className="font-weight-bold text-uppercase">Diet</h6>
                                                <div className="row">
                                                    <ul className="col" style={{ listStyleType: "none", padding: "0%" }}>
                                                        <li className="itm">
                                                            <input type="checkbox" value="vegetarian" name="health" onChange={checkboxHealth} />
                                                            <label>Vegetarian</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="vegan" name="health" onChange={checkboxHealth} />
                                                            <label>Vegan</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="paleo" name="health" onChange={checkboxHealth} />
                                                            <label>Paleo</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="high-fiber" name="diet" onChange={checkbox} />
                                                            <label>High-Fiber</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="high-protein" name="diet" onChange={checkbox} />
                                                            <label>High-Protein</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-carb" name="diet" onChange={checkbox} />
                                                            <label>Low-Carb</label>
                                                        </li>
                                                    </ul>
                                                    <ul className="col" style={{ listStyleType: "none", padding: "0%" }}>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-fat" name="diet" onChange={checkbox} />
                                                            <label>Low-Fat</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-sodium" name="diet" onChange={checkbox} />
                                                            <label>Low-Sodium</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="sugar-conscious" name="health" onChange={checkboxHealth} />
                                                            <label>Low-Sugar</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="alcohol-free" name="health" onChange={checkboxHealth} />
                                                            <label>Alcohol-Free</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="balanced" name="diet" onChange={checkbox} />
                                                            <label>Balanced</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="immuno-supportive" name="health" onChange={checkboxHealth} />
                                                            <label>Immunity</label>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div className="col-4">
                                                <h6 className="font-weight-bold text-uppercase">Alergies</h6>
                                                <div className="row">
                                                    <ul className="col" style={{ listStyleType: "none", padding: "0%" }}>
                                                        <li className="itm">
                                                            <input type="checkbox" value="vegetarian" name="health" onChange={checkboxHealth} />
                                                            <label>Vegetarian</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="vegan" name="health" onChange={checkboxHealth} />
                                                            <label>Vegan</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="paleo" name="health" onChange={checkboxHealth} />
                                                            <label>Paleo</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="high-fiber" name="diet" onChange={checkbox} />
                                                            <label>High-Fiber</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="high-protein" name="diet" onChange={checkbox} />
                                                            <label>High-Protein</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-carb" name="diet" onChange={checkbox} />
                                                            <label>Low-Carb</label>
                                                        </li>
                                                    </ul>
                                                    <ul className="col" style={{ listStyleType: "none", padding: "0%" }}>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-fat" name="diet" onChange={checkbox} />
                                                            <label>Low-Fat</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="low-sodium" name="diet" onChange={checkbox} />
                                                            <label>Low-Sodium</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="sugar-conscious" name="health" onChange={checkboxHealth} />
                                                            <label>Low-Sugar</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="alcohol-free" name="health" onChange={checkboxHealth} />
                                                            <label>Alcohol-Free</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="balanced" name="diet" onChange={checkbox} />
                                                            <label>Balanced</label>
                                                        </li>
                                                        <li className="itm">
                                                            <input type="checkbox" value="immuno-supportive" name="health" onChange={checkboxHealth} />
                                                            <label>Immunity</label>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section style={{ paddingLeft: "500px", paddingRight: "400px", paddingTop: "10px", paddingBottom: "10px" }}>
                <div className="container-fluid">
                    <div className="home-top-box" style={{ marginBottom: "20px" }}>
                        <div className="headline" style={{ marginBottom: "#000054 solid;" }}>
                            <h2>Results</h2>
                        </div>
                    </div>
                    <div className="row">
                        {userRecipeReturn.map((data) => {
                            return <div className="col">
                                <div className="card" style={{ width: "12rem", border: "none", borderRadius: "2px" }}>
                                    <img className="card-img-top" src={data.image} alt="Card image cap" style={{ borderRadius: "5px" }} />
                                    <div className="card-body">
                                        <a href="/foodAdded" className="card-title" style={{ color: "black" }} onClick={() => {
                                            window.sessionStorage.setItem("foodId", data.id)
                                        }}>{data.name}</a>
                                    </div>
                                </div>
                            </div>;
                        })}
                    </div>
                </div>
            </section>
            <section style={{ paddingLeft: "500px", paddingRight: "400px", paddingTop: "10px", paddingBottom: "10px" }}>
                <div className="container-fluid">
                    <div className="home-top-box" style={{ marginBottom: "20px" }}>
                        <div className="headline" style={{ marginBottom: "#000054 solid;" }}>
                            <h2>Results</h2>
                        </div>
                    </div>
                    <div className="row">
                        {recipeDataReturn.map((data) => {
                            return <div className="col">
                                <div className="card" style={{ width: "12rem", border: "none", borderRadius: "2px" }}>
                                    <img className="card-img-top" src={data.recipe.image} alt="Card image cap" style={{ borderRadius: "5px" }} />
                                    <div className="card-body">
                                        <a href="/displayData" className="card-title" style={{ color: "black" }} onClick={() => {
                                            window.sessionStorage.setItem("recipe_id", data._links.self.href)
                                        }}>{data.recipe.label}</a>
                                    </div>
                                </div>
                            </div>;
                        })}
                    </div>
                </div>
            </section>
            <div className="form-group">
            <button type="button" className="btn btn-light form-control" onClick={() => next()}>More</button>
            </div>
        </div>
    )
}
/*
    
*/
function DisplayCustomerFood(prop) {
    let history = useHistory();
    var endPoint = "/food/place/place";
    const [selectedFile, setSelectedFile] = useState(null);
    const [ingredients, setIngredients] = useState({ added: [] });
    const [foodDiet, setFoodDiet] = useState({ added: [] });
    const [steps, setSteps] = useState({ added: [] });
    const [value, setValue] = useState({ added: [{ foodName: "", foodCalories: 0, foodDescription: "" }] });
    var dietValues = ["Vegetarian", "Vegan", "Paleo", "High-Fiber", "High-Protein", "Low-Carb", "Low-Fat", "Low-Sodium", "Low-Sugar", "Alcohol-Free", "Balanced", "Immunity"];
    var count = -1;
    var countCountcountCount = -1;
    var source = "";
    var slice1 = "";
    if (selectedFile === null) {

    } else {
        source = selectedFile.profileImg
        console.log("source", slice1)
    }
    var imageHandler = (e) => {
        const reader = new FileReader();
        reader.onload = () => {
            if (reader.readyState === 2) {
                setSelectedFile({ profileImg: reader.result })
            }
        }
        reader.readAsDataURL(e.target.files[0])
    };
    const load = () => {
        fetch(endPoint, {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({ name: value.added[0].foodName.toLowerCase(), description: value.added[0].foodDescription, image: source, ingredients: ingredients.added, diet: foodDiet.added, steps: steps.added, calories: value.added[0].foodCalories, customerId: prop.display.id })
        }).then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({ id: prop.display.id });
                    history.push("/display");
                }
                
            });
    };
    const placesPlacesplaces = () => {
        var ingredientValues = ingredients.added;
        ingredientValues.push({ ingredientName: "", ingredientNum: 0, ingredientLast: "" });
        setIngredients({ added: ingredientValues });
    };
    const placesPlacesplacesPlaces = () => {
        var stepValues = steps.added;
        stepValues.push({ stepNum: steps.added.length, stepDetail: "" });
        setSteps({ added: stepValues });
    };
    const idPlacesplacesPlaces = () => {
        if (undefined === prop.display.noDisplay) {
        } else {
            history.push("/place");
        }
    };
    useEffect(
        idPlacesplacesPlaces
    );
    return (
        <div>
            <section
                style={{
                    paddingLeft: "500px",
                    paddingRight: "400px",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                }}
            >
                <div className="container">
                    <div className="text-center form-group">
                        <span className="display-4">Create New Recipe</span>
                    </div>
                    <div className="form-group">
                        <img src={source} width="400px" />
                        <input type="file" className="" onChange={imageHandler}></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control" value={value.added[0].foodName} onChange={(e) => { setValue({ added: [{ foodName: e.target.value, foodCalories: value.added[0].foodCalories, foodDescription: value.added[0].foodDescription }] }) }}
                            placeholder="Enter the name of the recipe"
                        ></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control" value={value.added[0].foodDescription} onChange={(e) => { setValue({ added: [{ foodName: value.added[0].foodName, foodCalories: value.added[0].foodCalories, foodDescription: e.target.value }] }) }}
                            placeholder="Short description of the recipe"
                        ></input>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Ingredient</h3>
                        {ingredients.added.map((placesPlaces) => {
                            count = count + 1;
                            var index = count;
                            var ingredient = <div className="row"><div className="col"><label>Name of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientName} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientName = e.target.value; setIngredients({ added: ingredientsPlaces }); }}></input></div><div className="col"><label>Amount of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientNum} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientNum = parseInt(e.target.value); setIngredients({ added: ingredientsPlaces }); }}></input></div><div className="col"><label>Last Place of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientLast} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientLast = e.target.value; setIngredients({ added: ingredientsPlaces }); }}></input></div></div>;
                            return ingredient;
                        })}
                    </div>
                    <div className="form-group">
                        <button className="btn btn-outline-primary" onClick={placesPlacesplaces}>+</button>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Calories</h3>
                        <input type="text" className="form-control w-50" value={value.added[0].foodCalories} onChange={(e) => { setValue({ added: [{ foodName: value.added[0].foodName, foodCalories: parseInt(e.target.value), foodDescription: value.added[0].foodDescription }] }) }}></input>
                        <div className="form-group">
                            <h3 style={{ fontWeight: "bold" }}>Diet</h3>
                            <ul className="row" style={{ marginLeft: "1px", listStyleType: "none" }}>
                                {dietValues.map((placesPlaces) => {
                                    var diet = <div className="col-6"><li className="itm"><input type="checkbox" value={placesPlaces} onChange={(e) => { var dietPlaces = foodDiet.added; if (!e.target.checked) { dietPlaces.splice(getIndex(dietPlaces, e.target.value), 1) } else { dietPlaces.push({ dietName: e.target.value }); }; setFoodDiet({ added: dietPlaces }); }} name="health" /><label>{placesPlaces}</label></li></div>;
                                    return diet;
                                })}
                            </ul>
                        </div>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Steps</h3>
                        {steps.added.map((placesPlaces) => {
                            countCountcountCount = countCountcountCount + 1;
                            var index = countCountcountCount;
                            var step = <div><input type="text" className="form-control" value={steps.added[index].stepDetail} onChange={(e) => { var stepsPlaces = steps.added; stepsPlaces[index].stepDetail = e.target.value; setSteps({ added: stepsPlaces }); }}></input></div>;
                            return step;
                        })}
                    </div>
                    <div style={{marginBottom: "10px"}}>
                        <button className="btn btn-outline-primary" onClick={placesPlacesplacesPlaces}>+ more steps</button>
                    </div>
                    <div>
                        <button className="btn btn-outline-primary" onClick={load}>Submit</button>
                    </div>
                </div>
            </section>
        </div>
    );
}
function DisplayCustomerFoodUpdate(prop) {
    let history = useHistory();
    var endPoint = "/food/place/place" + "/" + prop.foodValue.id;
    var endpoint2 = "/food/update/display";
    const [selectedFile, setSelectedFile] = useState(null);
    const [ingredients, setIngredients] = useState({ added: [] });
    const [foodDiet, setFoodDiet] = useState({ added: [] });
    const [steps, setSteps] = useState({ added: [] });
    const [value, setValue] = useState({ added: [{ foodName: "", foodCalories: 0, foodDescription: "" }] });
    var dietValues = ["Vegetarian", "Vegan", "Paleo", "High-Fiber", "High-Protein", "Low-Carb", "Low-Fat", "Low-Sodium", "Low-Sugar", "Alcohol-Free", "Balanced", "Immunity"];
    var count = -1;
    var countCountcountCount = -1;
    var source = "";
    var slice1 = "";
    if (selectedFile === null) {

    } else {
        source = selectedFile.profileImg
        console.log("source", slice1)
    }
    var imageHandler = (e) => {
        const reader = new FileReader();
        reader.onload = () => {
            if (reader.readyState === 2) {
                setSelectedFile({ profileImg: reader.result })
            }
        }
        reader.readAsDataURL(e.target.files[0])
    };
    const load = () => {
        fetch(endPoint, {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    setIngredients({ added: data[0].ingredients });
                setFoodDiet({ added: data[0].diet });
                setSteps({ added: data[0].steps });
                setValue({ added: [{ foodName: data[0].name, foodCalories: data[0].calories, foodDescription: data[0].description }] });
                setSelectedFile({ profileImg: data[0].image });
                }
                
            });
    };
    const updateFood = () => {
        fetch(endpoint2, {
            method: "PUT",
            headers: {
                'Content-Type': 'application/json',
                'x-access-token': window.sessionStorage.getItem("token")
            },
            body: JSON.stringify({ id: prop.foodValue.id, name: value.added[0].foodName.toLowerCase(), description: value.added[0].description, ingredients: ingredients.added, image: selectedFile.profileImg, diet: foodDiet.added, steps: steps.added, calories: value.added[0].foodCalories, customerId: prop.display.id })
        })
            .then(response => response.json())
            .then(data => {
                if (typeof data === "string" && "invalid token" == data) {

                } else {
                    prop.addId({id:prop.display.id});
                    history.push("/customerPlace");
                }
            });
    }
    const placesPlacesplaces = () => {
        var ingredientValues = ingredients.added;
        ingredientValues.push({ ingredientName: "", ingredientNum: 0, ingredientLast: "" });
        setIngredients({ added: ingredientValues });
    };
    const placesPlacesplacesPlaces = () => {
        var stepValues = steps.added;
        stepValues.push({ stepNum: steps.added.length, stepDetail: "" });
        setSteps({ added: stepValues });
    };
    const idPlacesplacesPlaces = () => {
        if (undefined === prop.display.noDisplay) {
            load();
        } else {
            history.push("/place");
        }
    };
    const healthArr = [];
    for (let i = 0; i < foodDiet.added.length; i++) {
        healthArr.push(foodDiet.added[i].dietName);
    }
    useEffect(
        idPlacesplacesPlaces, []
    );
    return (
        <div>
            <section
                style={{
                    paddingLeft: "500px",
                    paddingRight: "400px",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                }}
            >
                <div className="container">
                    <div className="text-center form-group">
                        <span className="display-4">Update Recipe</span>
                    </div>
                    <div className="form-group">
                        <img src={source} width="400px" />
                        <input type="file" className="" onChange={imageHandler}></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control" value={value.added[0].foodName} onChange={(e) => { setValue({ added: [{ foodName: e.target.value, foodCalories: value.added[0].foodCalories, foodDescription: value.added[0].foodDescription }] }) }}
                            placeholder="Enter the name of the recipe"
                        ></input>
                    </div>
                    <div className="form-group">
                        <input
                            type="text"
                            className="form-control" value={value.added[0].foodDescription} onChange={(e) => { setValue({ added: [{ foodName: value.added[0].foodName, foodCalories: value.added[0].foodCalories, foodDescription: e.target.value }] }) }}
                            placeholder="Short description of the recipe"
                        ></input>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Ingredient</h3>
                        {ingredients.added.map((placesPlaces) => {
                            count = count + 1;
                            var index = count;
                            var ingredient = <div className="row"><div className="col"><label>Name of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientName} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientName = e.target.value; setIngredients({ added: ingredientsPlaces }); }}></input></div><div className="col"><label>Amount of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientNum} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientNum = parseInt(e.target.value); setIngredients({ added: ingredientsPlaces }); }}></input></div><div className="col"><label>Last Place of Ingredient</label><input type="text" className="form-control" value={ingredients.added[index].ingredientLast} onChange={(e) => { var ingredientsPlaces = ingredients.added; ingredientsPlaces[index].ingredientLast = e.target.value; setIngredients({ added: ingredientsPlaces }); }}></input></div></div>;
                            return ingredient;
                        })}
                    </div>
                    <div className="form-group">
                        <button className="btn btn-outline-primary" onClick={placesPlacesplaces}>+</button>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Calories</h3>
                        <input type="text" className="form-control w-50" value={value.added[0].foodCalories} onChange={(e) => { setValue({ added: [{ foodName: value.added[0].foodName, foodCalories: parseInt(e.target.value), foodDescription: value.added[0].foodDescription }] }) }}></input>
                        <div className="form-group">
                            <h3 style={{ fontWeight: "bold" }}>Diet</h3>
                            <ul className="row" style={{ marginLeft: "1px", listStyleType: "none" }}>
                                {dietValues.map((placesPlaces) => {
                                    let state = ""
                                    if (healthArr.includes(placesPlaces)) {
                                        state = "true"
                                    } else {
                                        state = ""
                                    }
                                    var diet = <div className="col-6"><li className="itm"><input type="checkbox" checked={state} value={placesPlaces} onChange={(e) => { var dietPlaces = foodDiet.added; if (!e.target.checked) { dietPlaces.splice(getIndex(dietPlaces, e.target.value), 1) } else { dietPlaces.push({ dietName: e.target.value }); }; setFoodDiet({ added: dietPlaces }); }} name="health" /><label>{placesPlaces}</label></li></div>;
                                    console.log(state);
                                    return diet;
                                })}
                            </ul>
                        </div>
                    </div>
                    <div className="form-group">
                        <h3 style={{ fontWeight: "bold" }}>Steps</h3>
                        {steps.added.map((placesPlaces) => {
                            countCountcountCount = countCountcountCount + 1;
                            var index = countCountcountCount;
                            var step = <div><input type="text" className="form-control" value={steps.added[index].stepDetail} onChange={(e) => { var stepsPlaces = steps.added; stepsPlaces[index].stepDetail = e.target.value; setSteps({ added: stepsPlaces }); }}></input></div>;
                            return step;
                        })}
                    </div>
                    <div style={{marginBottom: "10px"}}>
                        <button className="btn btn-outline-primary" onClick={placesPlacesplacesPlaces}>+ more steps</button>
                    </div>
                    <div>
                        <button className="btn btn-outline-primary" onClick={updateFood}>Submit</button>
                    </div>
                </div>
            </section>
        </div>
    );
}
function DisplayPlacesPlacesPlaces(prop) {
    let history = useHistory();
    const load = () => {
        window.sessionStorage.setItem("value", 0);
        if (0 == prop.valueDoNotShow) {
            prop.addValueDoNotDisplay(1);
        } else {
            prop.addValueDoNotDisplay(0);
        }
        history.push("/list");
    }
    return <div style={{ display: "inline-block", marginRight:"630px" }}><button className="btn btn-outline-light" onClick={load}>Search</button></div>;
}
function Place() {
    const [value, setValue] = useState({});
    const [valueReturn, setValueReturn] = useState("");
    const [valueDoNotDisplay, setValueDoNotDisplay] = useState(0);
    if (0 != Object.keys(value).length) {
    } else {
        if (null === window.sessionStorage.getItem("id")) {
            setValue({ noDisplay: "No Display" });
        } else {
            setValue({ id: window.sessionStorage.getItem("id") });
        }
    }
    var foodId = {};
    if (null === window.sessionStorage.getItem("foodId")) {
        foodId = { noDisplay: "No Display" };
    } else {
        foodId = { id: window.sessionStorage.getItem("foodId") };
    }
    const [food, setFood] = useState(foodId);
    var recipeId = {};
    if (null === window.sessionStorage.getItem("recipe_id")) {
        recipeId = { noDisplay: "No Display" };
    } else {
        recipeId = { id: window.sessionStorage.getItem("recipe_id") }
    }
    return (
        <Router>
            <nav className="navbar navbar-light " style={{ backgroundColor: "#e60028" }}>
                <div className="container">
                    <form className="d-flex">
                        <a href="/display"><img style={{maxWidth:"40px"}} src="data:image/svg+xml;base64,PHN2ZyBoZWlnaHQ9IjUxMiIgdmlld0JveD0iMCAwIDUxMiA1MTIiIHdpZHRoPSI1MTIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgaWQ9ImZpbGxlZF9vdXRsaW5lIiBkYXRhLW5hbWU9ImZpbGxlZCBvdXRsaW5lIj48cGF0aCBkPSJtMzkyIDM5MmgzMmEwIDAgMCAwIDEgMCAwdjc2YTIwIDIwIDAgMCAxIC0yMCAyMGgtMTJhMCAwIDAgMCAxIDAgMHYtOTZhMCAwIDAgMCAxIDAgMHoiIGZpbGw9IiM5NjFiMjAiLz48cGF0aCBkPSJtODggMjRoMzE2YTIwIDIwIDAgMCAxIDIwIDIwdjM2MGEyMCAyMCAwIDAgMSAtMjAgMjBoLTMxNmEwIDAgMCAwIDEgMCAwdi00MDBhMCAwIDAgMCAxIDAgMHoiIGZpbGw9IiNlODJmM2UiLz48cGF0aCBkPSJtMzc2IDE5MmE2NCA2NCAwIDAgMCAtNjAuNjM1LTYzLjkxMSA2NCA2NCAwIDAgMCAtMTE4Ljc2Ny4wOTRjLTEuNTItLjEwOS0zLjA1LS4xODMtNC42LS4xODNhNjQuMDA5IDY0LjAwOSAwIDAgMCAtMTYgMTI1Ljk4NHY1OC4wMTZoMTYwLjAwMnYtNjAuNjdhNjQuMDA3IDY0LjAwNyAwIDAgMCA0MC01OS4zM3oiIGZpbGw9IiNlYWVhZTgiLz48cGF0aCBkPSJtODggNDI0LTQ4IDMydi00MDBhMzIgMzIgMCAwIDEgMzItMzJoMTZ6IiBmaWxsPSIjOTYxYjIwIi8+PGcgZmlsbD0iI2NiY2JjYiI+PHBhdGggZD0ibTMwNC4wMDYgMjYxLjk4NWE4LjAyNCA4LjAyNCAwIDAgMSAtMi0uMjU0IDcxLjYxIDcxLjYxIDAgMCAxIC0zMy40OTEtMTkuNGgtMjUuMDNhNzEuNjEgNzEuNjEgMCAwIDEgLTMzLjQ5MSAxOS40IDggOCAwIDEgMSAtMy45ODgtMTUuNSA1NS43NjEgNTUuNzYxIDAgMCAwIDI4LTE3LjIgOCA4IDAgMCAxIDYtMi43MDZoMzJhOCA4IDAgMCAxIDYgMi43MDYgNTUuNzYxIDU1Ljc2MSAwIDAgMCAyOCAxNy4yIDggOCAwIDAgMSAtMS45ODggMTUuNzV6Ii8+PHBhdGggZD0ibTIxNiAzMjBhOCA4IDAgMCAxIC04LTh2LTMyYTggOCAwIDAgMSAxNiAwdjMyYTggOCAwIDAgMSAtOCA4eiIvPjxwYXRoIGQ9Im0yOTYgMzIwYTggOCAwIDAgMSAtOC04di0zMmE4IDggMCAwIDEgMTYgMHYzMmE4IDggMCAwIDEgLTggOHoiLz48cGF0aCBkPSJtMjU2IDMyMGE4IDggMCAwIDEgLTgtOHYtMzJhOCA4IDAgMCAxIDE2IDB2MzJhOCA4IDAgMCAxIC04IDh6Ii8+PHBhdGggZD0ibTE3NiAzMTJoMTYwdjMyaC0xNjB6Ii8+PC9nPjxwYXRoIGQ9Im03MiA0MjRoMzIwYTAgMCAwIDAgMSAwIDB2NjRhMCAwIDAgMCAxIDAgMGgtMzIwYTMyIDMyIDAgMCAxIC0zMi0zMiAzMiAzMiAwIDAgMSAzMi0zMnoiIGZpbGw9IiNlYWVhZTgiLz48cGF0aCBkPSJtNDI0IDg4aDQ4bC0xNiAyNCAxNiAyNGgtNDh6IiBmaWxsPSIjMDJhNDM3Ii8+PHBhdGggZD0ibTQyNCAxNjhoNjRsLTE2IDI0IDE2IDI0aC02NHoiIGZpbGw9IiMwMDljZjciLz48cGF0aCBkPSJtMjI0IDM5MmgtMjRhOCA4IDAgMCAxIDAtMTZoMjRhOCA4IDAgMCAxIDAgMTZ6IiBmaWxsPSIjOTYxYjIwIi8+PHBhdGggZD0ibTMyMCAzOTJoLTY0YTggOCAwIDAgMSAwLTE2aDY0YTggOCAwIDAgMSAwIDE2eiIgZmlsbD0iIzk2MWIyMCIvPjxwYXRoIGQ9Im00MjQgMTM2LTExMi0xMTJoOTJhMjAgMjAgMCAwIDEgMjAgMjB6IiBmaWxsPSIjZmJiNTQwIi8+PGNpcmNsZSBjeD0iMzY4IiBjeT0iODAiIGZpbGw9IiNlYTlkMmQiIHI9IjI0Ii8+PHBhdGggZD0ibTEyMCA0NjRoLTQ4YTggOCAwIDAgMSAwLTE2aDQ4YTggOCAwIDAgMSAwIDE2eiIgZmlsbD0iI2NiY2JjYiIvPjxwYXRoIGQ9Im0xNjAgNDY0aC04YTggOCAwIDAgMSAwLTE2aDhhOCA4IDAgMCAxIDAgMTZ6IiBmaWxsPSIjY2JjYmNiIi8+PHBhdGggZD0ibTM5MiA0NjRoLTIwMGE4IDggMCAwIDEgMC0xNmgyMDB6IiBmaWxsPSIjY2JjYmNiIi8+PHBhdGggZD0ibTMwNS45OTQgMjQ2LjIzNWE1NS43NjEgNTUuNzYxIDAgMCAxIC0yOC0xNy4yIDggOCAwIDAgMCAtNi0yLjcwNmgtMzEuOTk0YTggOCAwIDAgMCAtNiAyLjcwNiA1NS43NjEgNTUuNzYxIDAgMCAxIC0yOCAxNy4yIDggOCAwIDEgMCAzLjk4OCAxNS41IDcxLjYxIDcxLjYxIDAgMCAwIDMzLjQ5MS0xOS40aDI1LjAzYTcxLjYxIDcxLjYxIDAgMCAwIDMzLjQ5MSAxOS40IDggOCAwIDEgMCAzLjk4OC0xNS41eiIvPjxwYXRoIGQ9Im0zMjAuNzYgMTIwLjUyOWE3MiA3MiAwIDAgMCAtMTI5LjI2LS41MjkgNzIuMDEzIDcyLjAxMyAwIDAgMCAtMjMuNSAxMzkuOXY4NC4xYTggOCAwIDAgMCA4IDhoMTYwYTggOCAwIDAgMCA4LTh2LTg3LjVhNzIuMDA3IDcyLjAwNyAwIDAgMCAtMjMuMjQtMTM1Ljk3M3ptNy4yNCAyMTUuNDcxaC0xNDR2LTE2aDE0NHptNS05Mi4wODVhOCA4IDAgMCAwIC01IDcuNDE1djUyLjY3aC0yNHYtMjRhOCA4IDAgMCAwIC0xNiAwdjI0aC0yNHYtMjRhOCA4IDAgMCAwIC0xNiAwdjI0aC0yNHYtMjRhOCA4IDAgMCAwIC0xNiAwdjI0aC0yNHYtNTAuMDE3YTggOCAwIDAgMCAtNi4wMDYtNy43NDcgNTYuMDA5IDU2LjAwOSAwIDAgMSAxNC4wMDYtMTEwLjIzNmMxLjIgMCAyLjQ3Ni4wNTIgNC4wMjguMTYyYTcuOTkzIDcuOTkzIDAgMCAwIDcuOTkzLTUgNTYgNTYgMCAwIDEgMTAzLjkyNC0uMDgxIDggOCAwIDAgMCA3LjAwNiA1IDU2IDU2IDAgMCAxIDE4LjA0OSAxMDcuODM0eiIvPjxwYXRoIGQ9Im00OTUuMDU0IDE2NC4yMjZhOCA4IDAgMCAwIC03LjA1NC00LjIyNmgtNTZ2LTE2aDQwYTggOCAwIDAgMCA2LjY1Ni0xMi40MzhsLTEzLjA0MS0xOS41NjIgMTMuMDQxLTE5LjU2MmE4IDggMCAwIDAgLTYuNjU2LTEyLjQzOGgtNDB2LTM2YTI4LjAzMiAyOC4wMzIgMCAwIDAgLTI4LTI4aC0zMzJhNDAuMDQ1IDQwLjA0NSAwIDAgMCAtNDAgNDB2NDAwYTQwLjA0NSA0MC4wNDUgMCAwIDAgNDAgNDBoMzMyYTI4LjAzMiAyOC4wMzIgMCAwIDAgMjgtMjh2LTI0NGg1NmE4IDggMCAwIDAgNi42NTYtMTIuNDM4bC0xMy4wNDEtMTkuNTYyIDEzLjA0MS0xOS41NjJhOCA4IDAgMCAwIC4zOTgtOC4yMTJ6bS02My4wNTQtNjguMjI2aDI1LjA1MmwtNy43MDggMTEuNTYyYTggOCAwIDAgMCAwIDguODc2bDcuNzA4IDExLjU2MmgtMjUuMDUyem0tMzg0LTQwYTI0LjAyOCAyNC4wMjggMCAwIDEgMjQtMjRoOHYzODRoLThhMzkuNzg4IDM5Ljc4OCAwIDAgMCAtMjQgOC4wMjJ6bTMzNiAzOTJoLTE5MmE4IDggMCAwIDAgMCAxNmgxOTJ2MTZoLTMxMmEyNCAyNCAwIDAgMSAwLTQ4aDMxMnptMzIgMjBhMTIuMDEzIDEyLjAxMyAwIDAgMSAtMTIgMTJoLTR2LTQ4aDRhMjcuODM4IDI3LjgzOCAwIDAgMCAxMi0yLjcwN3ptMC02NS4wMDl2MS4wMDlhMTIuMDEzIDEyLjAxMyAwIDAgMSAtMTIgMTJoLTMwOHYtMzg0aDIxMi42ODZsMzEuNzU4IDMxLjc1OWEzMS45NzggMzEuOTc4IDAgMCAwIDQzLjggNDMuOGwzMS43NTYgMzEuNzU1em0tNjQtMzIyLjk5MWExNiAxNiAwIDEgMSAxNiAxNiAxNi4wMTkgMTYuMDE5IDAgMCAxIC0xNi0xNnptNjQgMzYuNjg2LTIwLjQ0NC0yMC40NDVhMzEuOTc4IDMxLjk3OCAwIDAgMCAtNDMuOC00My44bC0yMC40NDItMjAuNDQxaDcyLjY4NmExMi4wMTMgMTIuMDEzIDAgMCAxIDEyIDEyem00OS4zNDQgNzkuNzUyIDcuNzA4IDExLjU2MmgtNDEuMDUydi0zMmg0MS4wNTJsLTcuNzA4IDExLjU2MmE4IDggMCAwIDAgMCA4Ljg3NnoiLz48cGF0aCBkPSJtMjI0IDM3NmgtMjRhOCA4IDAgMCAwIDAgMTZoMjRhOCA4IDAgMCAwIDAtMTZ6Ii8+PHBhdGggZD0ibTMyMCAzNzZoLTY0YTggOCAwIDAgMCAwIDE2aDY0YTggOCAwIDAgMCAwLTE2eiIvPjxwYXRoIGQ9Im02NCA0NTZhOCA4IDAgMCAwIDggOGg0OGE4IDggMCAwIDAgMC0xNmgtNDhhOCA4IDAgMCAwIC04IDh6Ii8+PHBhdGggZD0ibTE1MiA0NjRoOGE4IDggMCAwIDAgMC0xNmgtOGE4IDggMCAwIDAgMCAxNnoiLz48L2c+PC9zdmc+" alt="" /></a>
                        <input className="form-control me-2" onChange={(e) => { setValueReturn(e.target.value) }} value={valueReturn} type="search" placeholder="Search" aria-label="Search"
                            style={{ marginLeft: "10px" }} />
                    </form>
                    <DisplayPlacesPlacesPlaces valueDoNotShow={valueDoNotDisplay} addValueDoNotDisplay={(valueDoNotShow) => { setValueDoNotDisplay(valueDoNotShow) }} />
                    <DisplayPlaces display={value} deleteId={(noDisplay) => { setValue(noDisplay) }} />
                </div>
            </nav>
            <section id="place">
                <Switch>
                    <Route path="/place">
                        <DisplayAndRegister addAddaddId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/display">
                        <DisplayPage />
                    </Route>
                    <Route path="/list">
                        <List valueDisplay={valueReturn} />
                    </Route>
                    <Route path="/customerPlace">
                        <DisplayCustomer display={value} addId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/foodAdded">
                        <DisplayFoodAdded display={foodId} customer={value} addId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/customerUpdate">
                        <DisplayCustomerUpdate display={value} addId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/customerFood">
                        <DisplayCustomerFood display={value} addId={(id) => { setValue(id) }} />
                    </Route>
                    <Route path="/displayData">
                        <GetData display={recipeId} customer={value} addId={(id) => { setValue(id) }}  />
                    </Route>
                    <Route path="/customerFoodUpdate">
                        <DisplayCustomerFoodUpdate display={value} foodValue={foodId} addId={(id) => { setValue(id) }} />
                    </Route>
                </Switch>
            </section>
            <footer className="page-footer font-small teal pt-4" style={{ backgroundColor: "#f3f3f3" }}>
                <div className="container-fluid text-center text-md-left">
                    <div className="row">
                        <div className="col mt-md-0 mt-3">
                            <h5 className="text-uppercase font-weight-bold">About us</h5>
                            <p>Team Something: </p>
                            <p>Ngo Van Dat s3817813 </p>
                            <p>Hoang Truc Hai s3818558 </p>
                            <p>Nguyen Tan Song Hao s3817884</p>
                            <p>Anh Tran s3740932</p>
                            <p>Minh Ngo s3838104 </p>
                        </div>
                    </div>
                </div>
                <div className="footer-copyright text-center py-3">© 2021 Copyright:
                </div>
            </footer>
        </Router>
    );
}
export default Place;
