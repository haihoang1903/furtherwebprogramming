import { useEffect, useState } from 'react';
export default function Upload(){
    const [selectedFile, setSelectedFile] = useState(null);
    var source = "";
    if(selectedFile===null){

    } else{
        source = selectedFile.profileImg
        console.log("source", typeof(source))
    }
    var imageHandler = (e) => {
        const reader = new FileReader();
        reader.onload = () =>{
          if(reader.readyState === 2){
            setSelectedFile({profileImg: reader.result})
          }
        }
        reader.readAsDataURL(e.target.files[0])
      };
    return(<div>
        <img src={source} width="400px"/>
        <input type="file"
          onChange={imageHandler}></input>
    </div>);
}